﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nzanzu_MUTANGA_fRAnk
{
    public partial class Jeu : Form
    {
     private int nbrdessaie;
        private int valeurachercher;
        private int phase;
        public Jeu()
        {
            InitializeComponent();
        }
        private void effacer()
        {
            txtValeur.Text = "";
            txtValeur.Focus();
        }

        private void Jeu_Load(object sender, EventArgs e)
        {
            init();
        }

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void init()
        {
            phase = 1;
            grpValeur.Text = " valeur (entre 1 et 100)";
            grpReponse.Visible = false;
            grpValeur.Enabled = true;
            txtValeur.Enabled = true;
            effacer();
        }


        private void btnValider_Click(object sender, EventArgs e)
        {
            try
            {
                int valeur = int.Parse(txtValeur.Text);
                if (valeur >= 1 && valeur <= 100)
                {
                    if (phase == 1)
                    {
                        valeurachercher = valeur;
                        phase = 2;
                        nbrdessaie = 0;
                        grpValeur.Text = "essai entre 1 et 100";
                        effacer();
                    }
                    else
                    {
                        if (valeur == valeurachercher)
                        {
                            lblMessage.Text = " bravo!! c'etait bien" + valeurachercher;
                            effacer();
                            grpValeur.Visible = false;
                            btnRejouer.Focus();
                            grpValeur.Visible = true;
                            txtValeur.Enabled = false;
                        }
                        else
                        {
                            if (valeur > valeurachercher)
                            {
                                lblMessage.Text = valeur + " est trop grand";
                            }
                            else
                            {
                                lblMessage.Text = valeur + " est trop petit";
                            }
                            effacer();
                        }
                        nbrdessaie++;
                        grpReponse.Text = "Essai N°" + nbrdessaie;
                        grpReponse.Visible = true;
                    }
                }
                else
                {
                    effacer();
                }

            }
            catch (Exception ex)
            {
                effacer();
            }
        }

        private void btnQuitter_Click_1(object sender, EventArgs e)
        {
             Application.Exit();
        }
        private void init()
        {
            phase = 1;
            grpValeur.Text = " valeur (entre 1 et 100)";
            grpReponse.Visible = false;
            grpValeur.Enabled = true;
            txtValeur.Enabled = true;
            effacer();
        }

        private void btnRejouer_Click(object sender, EventArgs e)
        {
            init();
        }

        private void txtValeur_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)
            {
                btnValider_Click(null, null);
            }
        }

        private void txtValeur_TextChanged(object sender, EventArgs e)
        {

        }

        private void grpReponse_Enter(object sender, EventArgs e)
        {

        }
    }

}

