﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nzanzu_MUTANGA_fRAnk
{
    public partial class Operation : Form
    {
        public Operation()
        {
            InitializeComponent();
        }

        private void txtnbr1_TextChanged(object sender, EventArgs e)
        {
            txtresult.Text = "";
        }

        private void txtnbr2_TextChanged(object sender, EventArgs e)
        {
            txtresult.Text = "";
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                txtresult.Text = (float.Parse(txtnbr1.Text) + float.Parse(txtnbr2.Text)).ToString();
                lblmulti.Text = "+";
            }
            catch (Exception ex) { }
        }

        private void btnmultip_Click(object sender, EventArgs e)
        {
            try
            {
                txtresult.Text = (float.Parse(txtnbr1.Text) * float.Parse(txtnbr2.Text)).ToString();
                lblmulti.Text = "x";
            }
            catch (Exception ex) { }
        }

        private void btngomme_Click(object sender, EventArgs e)
        {
            txtnbr1.Text = "";
            txtnbr2.Text = "";
            txtresult.Text = "";
        }

        private void btneteindre_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
