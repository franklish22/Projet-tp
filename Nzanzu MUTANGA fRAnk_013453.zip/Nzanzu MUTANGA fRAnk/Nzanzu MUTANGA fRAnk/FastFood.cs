﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nzanzu_MUTANGA_fRAnk
{
    public partial class FastFood : Form
    {
        public FastFood()
        {
            InitializeComponent();
        }

        private void FastFood_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Consultation cos = new Consultation();
            cos.Show();
        }

        private void BtnHome_Click(object sender, EventArgs e)
        {
            SidePanel.Height = BtnHome.Height;
            SidePanel.Top = BtnHome.Top;
            eat_in1.BringToFront();
        }

        private void BtnEatin_Click(object sender, EventArgs e)
        {
            SidePanel.Height = BtnHome.Height;
            SidePanel.Top = BtnEatin.Top;
            homeFastFood1.BringToFront();
        }

        private void SidePanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Calculatrice clc = new Calculatrice();
            clc.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
           Suivi sv = new Suivi();
            sv.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Vaccin vac = new Vaccin();
            vac.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            QRCode qr = new QRCode();
            qr.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Projet pj = new Projet();
            pj.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Operation op = new Operation();
            op.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Loging lg = new Loging();
            lg.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Jeu J = new Jeu();
            J.Show();
        }
    }
}
