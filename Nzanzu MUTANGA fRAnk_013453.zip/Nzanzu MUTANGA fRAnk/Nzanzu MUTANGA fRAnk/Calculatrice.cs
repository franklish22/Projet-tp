﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nzanzu_MUTANGA_fRAnk
{
    public partial class Calculatrice : Form
    {
        public Calculatrice()
        {
            InitializeComponent();
        }
        float n1, n2, resultat;
        string operateur;

        void traitement(float n1, float n2, string op)
        {
            n2 = float.Parse(TxtAffiche.Text);
            if(op =="+")
            {
                resultat = n1 + n2;
            }
            else if (op == "-")
            {
                resultat = n1 - n2;
            }
            else if (op == "X")
            {
                resultat = n1 * n2;
            }
            else if (op == "/")
            {
                resultat = n1 / n2;
            }
            TxtAffiche.Text = resultat.ToString();
        }
        private void Btn1_Click(object sender, EventArgs e)
        {
            TxtAffiche.Text = TxtAffiche.Text + "1";
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            TxtAffiche.Text = TxtAffiche.Text + "2";
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            TxtAffiche.Text = TxtAffiche.Text + "3";
        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            TxtAffiche.Text = TxtAffiche.Text + "4";
        }

        private void Btn5_Click(object sender, EventArgs e)
        {
            TxtAffiche.Text = TxtAffiche.Text + "5";
        }

        private void Btn6_Click(object sender, EventArgs e)
        {
            TxtAffiche.Text = TxtAffiche.Text + "6";
        }

        private void Btn7_Click(object sender, EventArgs e)
        {
            TxtAffiche.Text = TxtAffiche.Text + "7";
        }

        private void Btn8_Click(object sender, EventArgs e)
        {
            TxtAffiche.Text = TxtAffiche.Text + "8";
        }

        private void Btn9_Click(object sender, EventArgs e)
        {
            TxtAffiche.Text = TxtAffiche.Text + "9";
        }

        private void Btn0_Click(object sender, EventArgs e)
        {
            TxtAffiche.Text = TxtAffiche.Text + "0";
        }

        private void BtnVirg_Click(object sender, EventArgs e)
        {
            TxtAffiche.Text = TxtAffiche.Text + ".";
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            n1 = float.Parse(TxtAffiche.Text);
            operateur = "+";
            TxtAffiche.Text = "+";
        }

        private void BtnSoust_Click(object sender, EventArgs e)
        {
            n1 = float.Parse(TxtAffiche.Text);
            operateur = "-";
            TxtAffiche.Text = "-";
        }

        private void BtnMult_Click(object sender, EventArgs e)
        {
            n1 = float.Parse(TxtAffiche.Text);
            operateur = "X";
            TxtAffiche.Text = "X";
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            n1 = float.Parse(TxtAffiche.Text);
            operateur = "/";
            TxtAffiche.Text = "/";
        }

        private void BtnClean_Click(object sender, EventArgs e)
        {
            TxtAffiche.Text = "";
        }

        private void BtnEg_Click(object sender, EventArgs e)
        {
             n2 = float.Parse(TxtAffiche.Text);
            if (operateur == "+")
            {
                resultat = n1 + n2;
                //Affiche le resultat sur l'ecran
                TxtAffiche.Text = resultat.ToString();
            }
            else if (operateur == "-")
            {
                resultat = n1 - n2;
                //Affiche le resultat sur l'ecran
                TxtAffiche.Text = resultat.ToString();
            }
            else if (operateur == "X")
            {
                resultat = n1 * n2;
                //Affiche le resultat sur l'ecran
                TxtAffiche.Text = resultat.ToString();
            }
            else if (operateur == "/")
            {
                resultat = n1 / n2;
                //Affiche le resultat sur l'ecran
                TxtAffiche.Text = resultat.ToString();
        }
    }
 }
}
  
