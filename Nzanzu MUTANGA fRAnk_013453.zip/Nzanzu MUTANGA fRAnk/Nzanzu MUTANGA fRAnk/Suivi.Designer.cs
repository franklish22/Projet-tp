﻿namespace Nzanzu_MUTANGA_fRAnk
{
    partial class Suivi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.maskedTextBox19 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox18 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox17 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox16 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox15 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox14 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox13 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox12 = new System.Windows.Forms.MaskedTextBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.dataGridView104 = new System.Windows.Forms.DataGridView();
            this.CLM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label71 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.dataGridView103 = new System.Windows.Forms.DataGridView();
            this.dataGridView102 = new System.Windows.Forms.DataGridView();
            this.dataGridView101 = new System.Windows.Forms.DataGridView();
            this.dataGridView100 = new System.Windows.Forms.DataGridView();
            this.dataGridView99 = new System.Windows.Forms.DataGridView();
            this.dataGridView98 = new System.Windows.Forms.DataGridView();
            this.dataGridView97 = new System.Windows.Forms.DataGridView();
            this.dataGridView96 = new System.Windows.Forms.DataGridView();
            this.dataGridView95 = new System.Windows.Forms.DataGridView();
            this.dataGridView94 = new System.Windows.Forms.DataGridView();
            this.dataGridView93 = new System.Windows.Forms.DataGridView();
            this.dataGridView92 = new System.Windows.Forms.DataGridView();
            this.dataGridView91 = new System.Windows.Forms.DataGridView();
            this.dataGridView90 = new System.Windows.Forms.DataGridView();
            this.dataGridView89 = new System.Windows.Forms.DataGridView();
            this.dataGridView88 = new System.Windows.Forms.DataGridView();
            this.dataGridView87 = new System.Windows.Forms.DataGridView();
            this.dataGridView86 = new System.Windows.Forms.DataGridView();
            this.dataGridView85 = new System.Windows.Forms.DataGridView();
            this.dataGridView84 = new System.Windows.Forms.DataGridView();
            this.dataGridView83 = new System.Windows.Forms.DataGridView();
            this.dataGridView82 = new System.Windows.Forms.DataGridView();
            this.dataGridView81 = new System.Windows.Forms.DataGridView();
            this.dataGridView80 = new System.Windows.Forms.DataGridView();
            this.dataGridView79 = new System.Windows.Forms.DataGridView();
            this.dataGridView78 = new System.Windows.Forms.DataGridView();
            this.dataGridView77 = new System.Windows.Forms.DataGridView();
            this.dataGridView76 = new System.Windows.Forms.DataGridView();
            this.dataGridView75 = new System.Windows.Forms.DataGridView();
            this.dataGridView74 = new System.Windows.Forms.DataGridView();
            this.dataGridView73 = new System.Windows.Forms.DataGridView();
            this.dataGridView72 = new System.Windows.Forms.DataGridView();
            this.dataGridView71 = new System.Windows.Forms.DataGridView();
            this.dataGridView70 = new System.Windows.Forms.DataGridView();
            this.dataGridView69 = new System.Windows.Forms.DataGridView();
            this.dataGridView68 = new System.Windows.Forms.DataGridView();
            this.dataGridView67 = new System.Windows.Forms.DataGridView();
            this.dataGridView66 = new System.Windows.Forms.DataGridView();
            this.dataGridView65 = new System.Windows.Forms.DataGridView();
            this.dataGridView64 = new System.Windows.Forms.DataGridView();
            this.dataGridView63 = new System.Windows.Forms.DataGridView();
            this.dataGridView62 = new System.Windows.Forms.DataGridView();
            this.dataGridView61 = new System.Windows.Forms.DataGridView();
            this.dataGridView60 = new System.Windows.Forms.DataGridView();
            this.dataGridView59 = new System.Windows.Forms.DataGridView();
            this.dataGridView58 = new System.Windows.Forms.DataGridView();
            this.dataGridView57 = new System.Windows.Forms.DataGridView();
            this.dataGridView56 = new System.Windows.Forms.DataGridView();
            this.dataGridView55 = new System.Windows.Forms.DataGridView();
            this.dataGridView54 = new System.Windows.Forms.DataGridView();
            this.dataGridView53 = new System.Windows.Forms.DataGridView();
            this.dataGridView52 = new System.Windows.Forms.DataGridView();
            this.dataGridView51 = new System.Windows.Forms.DataGridView();
            this.dataGridView50 = new System.Windows.Forms.DataGridView();
            this.dataGridView49 = new System.Windows.Forms.DataGridView();
            this.dataGridView48 = new System.Windows.Forms.DataGridView();
            this.dataGridView47 = new System.Windows.Forms.DataGridView();
            this.dataGridView46 = new System.Windows.Forms.DataGridView();
            this.dataGridView45 = new System.Windows.Forms.DataGridView();
            this.dataGridView44 = new System.Windows.Forms.DataGridView();
            this.dataGridView43 = new System.Windows.Forms.DataGridView();
            this.dataGridView42 = new System.Windows.Forms.DataGridView();
            this.dataGridView41 = new System.Windows.Forms.DataGridView();
            this.dataGridView40 = new System.Windows.Forms.DataGridView();
            this.dataGridView39 = new System.Windows.Forms.DataGridView();
            this.dataGridView38 = new System.Windows.Forms.DataGridView();
            this.dataGridView37 = new System.Windows.Forms.DataGridView();
            this.dataGridView36 = new System.Windows.Forms.DataGridView();
            this.dataGridView35 = new System.Windows.Forms.DataGridView();
            this.dataGridView34 = new System.Windows.Forms.DataGridView();
            this.label61 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.dataGridView33 = new System.Windows.Forms.DataGridView();
            this.dataGridView32 = new System.Windows.Forms.DataGridView();
            this.dataGridView31 = new System.Windows.Forms.DataGridView();
            this.dataGridView30 = new System.Windows.Forms.DataGridView();
            this.dataGridView29 = new System.Windows.Forms.DataGridView();
            this.dataGridView28 = new System.Windows.Forms.DataGridView();
            this.dataGridView27 = new System.Windows.Forms.DataGridView();
            this.dataGridView26 = new System.Windows.Forms.DataGridView();
            this.dataGridView25 = new System.Windows.Forms.DataGridView();
            this.dataGridView24 = new System.Windows.Forms.DataGridView();
            this.dataGridView23 = new System.Windows.Forms.DataGridView();
            this.dataGridView22 = new System.Windows.Forms.DataGridView();
            this.dataGridView21 = new System.Windows.Forms.DataGridView();
            this.dataGridView20 = new System.Windows.Forms.DataGridView();
            this.dataGridView19 = new System.Windows.Forms.DataGridView();
            this.dataGridView18 = new System.Windows.Forms.DataGridView();
            this.dataGridView17 = new System.Windows.Forms.DataGridView();
            this.dataGridView16 = new System.Windows.Forms.DataGridView();
            this.dataGridView15 = new System.Windows.Forms.DataGridView();
            this.dataGridView14 = new System.Windows.Forms.DataGridView();
            this.dataGridView13 = new System.Windows.Forms.DataGridView();
            this.dataGridView12 = new System.Windows.Forms.DataGridView();
            this.dataGridView11 = new System.Windows.Forms.DataGridView();
            this.dataGridView10 = new System.Windows.Forms.DataGridView();
            this.dataGridView9 = new System.Windows.Forms.DataGridView();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.maskedTextBox11 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox10 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox9 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox8 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox7 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox6 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox5 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox4 = new System.Windows.Forms.MaskedTextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView104)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView103)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView102)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView101)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView100)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView99)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView98)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView97)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView96)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView95)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView94)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView93)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView92)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView91)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView90)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView89)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView88)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView87)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView86)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView85)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView84)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView83)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView82)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView81)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView80)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView79)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView78)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView77)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView76)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView75)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView74)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView73)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView72)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView71)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView70)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView69)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView68)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView67)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView66)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView65)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView64)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView63)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView62)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView57)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // maskedTextBox19
            // 
            this.maskedTextBox19.Location = new System.Drawing.Point(75, 665);
            this.maskedTextBox19.Name = "maskedTextBox19";
            this.maskedTextBox19.Size = new System.Drawing.Size(57, 20);
            this.maskedTextBox19.TabIndex = 906;
            // 
            // maskedTextBox18
            // 
            this.maskedTextBox18.Location = new System.Drawing.Point(96, 699);
            this.maskedTextBox18.Name = "maskedTextBox18";
            this.maskedTextBox18.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox18.TabIndex = 905;
            // 
            // maskedTextBox17
            // 
            this.maskedTextBox17.Location = new System.Drawing.Point(206, 728);
            this.maskedTextBox17.Name = "maskedTextBox17";
            this.maskedTextBox17.Size = new System.Drawing.Size(201, 20);
            this.maskedTextBox17.TabIndex = 904;
            // 
            // maskedTextBox16
            // 
            this.maskedTextBox16.Location = new System.Drawing.Point(392, 666);
            this.maskedTextBox16.Name = "maskedTextBox16";
            this.maskedTextBox16.Size = new System.Drawing.Size(57, 20);
            this.maskedTextBox16.TabIndex = 903;
            // 
            // maskedTextBox15
            // 
            this.maskedTextBox15.Location = new System.Drawing.Point(229, 665);
            this.maskedTextBox15.Name = "maskedTextBox15";
            this.maskedTextBox15.Size = new System.Drawing.Size(57, 20);
            this.maskedTextBox15.TabIndex = 902;
            // 
            // maskedTextBox14
            // 
            this.maskedTextBox14.Location = new System.Drawing.Point(423, 695);
            this.maskedTextBox14.Name = "maskedTextBox14";
            this.maskedTextBox14.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox14.TabIndex = 901;
            // 
            // maskedTextBox13
            // 
            this.maskedTextBox13.Location = new System.Drawing.Point(692, 666);
            this.maskedTextBox13.Name = "maskedTextBox13";
            this.maskedTextBox13.Size = new System.Drawing.Size(57, 20);
            this.maskedTextBox13.TabIndex = 900;
            // 
            // maskedTextBox12
            // 
            this.maskedTextBox12.Location = new System.Drawing.Point(542, 669);
            this.maskedTextBox12.Name = "maskedTextBox12";
            this.maskedTextBox12.Size = new System.Drawing.Size(57, 20);
            this.maskedTextBox12.TabIndex = 899;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(317, 702);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(91, 13);
            this.label79.TabIndex = 898;
            this.label79.Text = "Si non donner MII";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(154, 669);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(69, 13);
            this.label78.TabIndex = 897;
            this.label78.Text = "V.A.T 2/date";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(317, 669);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(69, 13);
            this.label77.TabIndex = 896;
            this.label77.Text = "V.A.T 3/date";
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(467, 669);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(69, 13);
            this.label76.TabIndex = 895;
            this.label76.Text = "V.A.T 4/date";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(619, 669);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(69, 13);
            this.label75.TabIndex = 894;
            this.label75.Text = "V.A.T 5/date";
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(0, 669);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(69, 13);
            this.label74.TabIndex = 893;
            this.label74.Text = "V.A.T 1/date";
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(0, 702);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(86, 13);
            this.label73.TabIndex = 892;
            this.label73.Text = "Dort sous mill oui";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(0, 731);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(187, 13);
            this.label72.TabIndex = 891;
            this.label72.Text = "Vemifuge  : Mabendazol au 2 trimestre";
            // 
            // dataGridView104
            // 
            this.dataGridView104.AllowUserToAddRows = false;
            this.dataGridView104.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView104.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView104.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CLM,
            this.Column5});
            this.dataGridView104.Location = new System.Drawing.Point(3, 2);
            this.dataGridView104.Name = "dataGridView104";
            this.dataGridView104.Size = new System.Drawing.Size(746, 62);
            this.dataGridView104.TabIndex = 890;
            // 
            // CLM
            // 
            this.CLM.Frozen = true;
            this.CLM.HeaderText = "D.D.R. :";
            this.CLM.Name = "CLM";
            this.CLM.Width = 270;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Date prévue Aee. :";
            this.Column5.Name = "Column5";
            this.Column5.Width = 500;
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(330, 565);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(58, 13);
            this.label71.TabIndex = 889;
            this.label71.Text = "Accessible";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(332, 613);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(87, 13);
            this.label70.TabIndex = 888;
            this.label70.Text = "Si > 2 -3 kg/mois";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(330, 515);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(64, 13);
            this.label69.TabIndex = 887;
            this.label69.Text = "8i présentes";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(330, 464);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(89, 13);
            this.label68.TabIndex = 886;
            this.label68.Text = "Si présente, culot";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(335, 415);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(94, 13);
            this.label67.TabIndex = 885;
            this.label67.Text = "Si > 140/90 mmhg";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(332, 379);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(106, 13);
            this.label66.TabIndex = 884;
            this.label66.Text = "Si glucosurie positive";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(332, 339);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(75, 13);
            this.label65.TabIndex = 883;
            this.label65.Text = "Si alb. positive";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(330, 296);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(62, 13);
            this.label64.TabIndex = 882;
            this.label64.Text = "Si oedèmes";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(317, 220);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(147, 13);
            this.label50.TabIndex = 881;
            this.label50.Text = "Si transverse à 7 mois ou plus";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(334, 182);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(98, 13);
            this.label48.TabIndex = 880;
            this.label48.Text = "Si Mvts foet et BCF";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(313, 156);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(160, 13);
            this.label46.TabIndex = 879;
            this.label46.Text = "Si écart avec l\'âge de grossesse";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(330, 111);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(48, 13);
            this.label41.TabIndex = 878;
            this.label41.Text = "Colorées";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(332, 75);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(132, 13);
            this.label39.TabIndex = 877;
            this.label39.Text = "A contrôler à chaque RDV";
            // 
            // label63
            // 
            this.label63.Location = new System.Drawing.Point(325, 616);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(41, 13);
            this.label63.TabIndex = 690;
            // 
            // label62
            // 
            this.label62.Location = new System.Drawing.Point(325, 565);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(41, 13);
            this.label62.TabIndex = 689;
            // 
            // label58
            // 
            this.label58.Location = new System.Drawing.Point(391, 515);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(41, 13);
            this.label58.TabIndex = 688;
            // 
            // label57
            // 
            this.label57.Location = new System.Drawing.Point(346, 463);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(41, 13);
            this.label57.TabIndex = 687;
            // 
            // label55
            // 
            this.label55.Location = new System.Drawing.Point(337, 428);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(41, 13);
            this.label55.TabIndex = 686;
            // 
            // label54
            // 
            this.label54.Location = new System.Drawing.Point(338, 379);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(41, 13);
            this.label54.TabIndex = 685;
            // 
            // label53
            // 
            this.label53.Location = new System.Drawing.Point(340, 351);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(41, 13);
            this.label53.TabIndex = 684;
            // 
            // label52
            // 
            this.label52.Location = new System.Drawing.Point(338, 297);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(41, 13);
            this.label52.TabIndex = 683;
            // 
            // label49
            // 
            this.label49.Location = new System.Drawing.Point(332, 220);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(41, 13);
            this.label49.TabIndex = 682;
            // 
            // dataGridView103
            // 
            this.dataGridView103.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView103.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView103.Location = new System.Drawing.Point(673, 590);
            this.dataGridView103.Name = "dataGridView103";
            this.dataGridView103.Size = new System.Drawing.Size(76, 51);
            this.dataGridView103.TabIndex = 876;
            // 
            // dataGridView102
            // 
            this.dataGridView102.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView102.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView102.Location = new System.Drawing.Point(609, 590);
            this.dataGridView102.Name = "dataGridView102";
            this.dataGridView102.Size = new System.Drawing.Size(69, 51);
            this.dataGridView102.TabIndex = 875;
            // 
            // dataGridView101
            // 
            this.dataGridView101.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView101.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView101.Location = new System.Drawing.Point(531, 590);
            this.dataGridView101.Name = "dataGridView101";
            this.dataGridView101.Size = new System.Drawing.Size(85, 51);
            this.dataGridView101.TabIndex = 874;
            // 
            // dataGridView100
            // 
            this.dataGridView100.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView100.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView100.Location = new System.Drawing.Point(470, 590);
            this.dataGridView100.Name = "dataGridView100";
            this.dataGridView100.Size = new System.Drawing.Size(72, 51);
            this.dataGridView100.TabIndex = 873;
            // 
            // dataGridView99
            // 
            this.dataGridView99.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView99.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView99.Location = new System.Drawing.Point(316, 590);
            this.dataGridView99.Name = "dataGridView99";
            this.dataGridView99.Size = new System.Drawing.Size(158, 51);
            this.dataGridView99.TabIndex = 872;
            // 
            // dataGridView98
            // 
            this.dataGridView98.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView98.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView98.Location = new System.Drawing.Point(673, 542);
            this.dataGridView98.Name = "dataGridView98";
            this.dataGridView98.Size = new System.Drawing.Size(76, 52);
            this.dataGridView98.TabIndex = 871;
            // 
            // dataGridView97
            // 
            this.dataGridView97.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView97.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView97.Location = new System.Drawing.Point(609, 542);
            this.dataGridView97.Name = "dataGridView97";
            this.dataGridView97.Size = new System.Drawing.Size(69, 52);
            this.dataGridView97.TabIndex = 870;
            // 
            // dataGridView96
            // 
            this.dataGridView96.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView96.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView96.Location = new System.Drawing.Point(533, 542);
            this.dataGridView96.Name = "dataGridView96";
            this.dataGridView96.Size = new System.Drawing.Size(81, 52);
            this.dataGridView96.TabIndex = 869;
            // 
            // dataGridView95
            // 
            this.dataGridView95.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView95.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView95.Location = new System.Drawing.Point(470, 542);
            this.dataGridView95.Name = "dataGridView95";
            this.dataGridView95.Size = new System.Drawing.Size(72, 52);
            this.dataGridView95.TabIndex = 868;
            // 
            // dataGridView94
            // 
            this.dataGridView94.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView94.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView94.Location = new System.Drawing.Point(316, 542);
            this.dataGridView94.Name = "dataGridView94";
            this.dataGridView94.Size = new System.Drawing.Size(158, 52);
            this.dataGridView94.TabIndex = 867;
            // 
            // dataGridView93
            // 
            this.dataGridView93.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView93.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView93.Location = new System.Drawing.Point(673, 491);
            this.dataGridView93.Name = "dataGridView93";
            this.dataGridView93.Size = new System.Drawing.Size(76, 55);
            this.dataGridView93.TabIndex = 866;
            // 
            // dataGridView92
            // 
            this.dataGridView92.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView92.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView92.Location = new System.Drawing.Point(609, 491);
            this.dataGridView92.Name = "dataGridView92";
            this.dataGridView92.Size = new System.Drawing.Size(69, 55);
            this.dataGridView92.TabIndex = 865;
            // 
            // dataGridView91
            // 
            this.dataGridView91.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView91.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView91.Location = new System.Drawing.Point(533, 491);
            this.dataGridView91.Name = "dataGridView91";
            this.dataGridView91.Size = new System.Drawing.Size(81, 54);
            this.dataGridView91.TabIndex = 864;
            // 
            // dataGridView90
            // 
            this.dataGridView90.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView90.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView90.Location = new System.Drawing.Point(470, 491);
            this.dataGridView90.Name = "dataGridView90";
            this.dataGridView90.Size = new System.Drawing.Size(72, 54);
            this.dataGridView90.TabIndex = 863;
            // 
            // dataGridView89
            // 
            this.dataGridView89.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView89.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView89.Location = new System.Drawing.Point(316, 491);
            this.dataGridView89.Name = "dataGridView89";
            this.dataGridView89.Size = new System.Drawing.Size(158, 54);
            this.dataGridView89.TabIndex = 862;
            // 
            // dataGridView88
            // 
            this.dataGridView88.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView88.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView88.Location = new System.Drawing.Point(673, 444);
            this.dataGridView88.Name = "dataGridView88";
            this.dataGridView88.Size = new System.Drawing.Size(76, 49);
            this.dataGridView88.TabIndex = 861;
            // 
            // dataGridView87
            // 
            this.dataGridView87.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView87.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView87.Location = new System.Drawing.Point(609, 444);
            this.dataGridView87.Name = "dataGridView87";
            this.dataGridView87.Size = new System.Drawing.Size(69, 49);
            this.dataGridView87.TabIndex = 860;
            // 
            // dataGridView86
            // 
            this.dataGridView86.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView86.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView86.Location = new System.Drawing.Point(533, 444);
            this.dataGridView86.Name = "dataGridView86";
            this.dataGridView86.Size = new System.Drawing.Size(81, 49);
            this.dataGridView86.TabIndex = 859;
            // 
            // dataGridView85
            // 
            this.dataGridView85.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView85.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView85.Location = new System.Drawing.Point(470, 444);
            this.dataGridView85.Name = "dataGridView85";
            this.dataGridView85.Size = new System.Drawing.Size(72, 49);
            this.dataGridView85.TabIndex = 858;
            // 
            // dataGridView84
            // 
            this.dataGridView84.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView84.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView84.Location = new System.Drawing.Point(316, 444);
            this.dataGridView84.Name = "dataGridView84";
            this.dataGridView84.Size = new System.Drawing.Size(158, 49);
            this.dataGridView84.TabIndex = 857;
            // 
            // dataGridView83
            // 
            this.dataGridView83.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView83.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView83.Location = new System.Drawing.Point(673, 403);
            this.dataGridView83.Name = "dataGridView83";
            this.dataGridView83.Size = new System.Drawing.Size(76, 47);
            this.dataGridView83.TabIndex = 856;
            // 
            // dataGridView82
            // 
            this.dataGridView82.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView82.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView82.Location = new System.Drawing.Point(609, 403);
            this.dataGridView82.Name = "dataGridView82";
            this.dataGridView82.Size = new System.Drawing.Size(69, 47);
            this.dataGridView82.TabIndex = 855;
            // 
            // dataGridView81
            // 
            this.dataGridView81.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView81.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView81.Location = new System.Drawing.Point(533, 403);
            this.dataGridView81.Name = "dataGridView81";
            this.dataGridView81.Size = new System.Drawing.Size(83, 47);
            this.dataGridView81.TabIndex = 854;
            // 
            // dataGridView80
            // 
            this.dataGridView80.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView80.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView80.Location = new System.Drawing.Point(470, 403);
            this.dataGridView80.Name = "dataGridView80";
            this.dataGridView80.Size = new System.Drawing.Size(72, 47);
            this.dataGridView80.TabIndex = 853;
            // 
            // dataGridView79
            // 
            this.dataGridView79.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView79.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView79.Location = new System.Drawing.Point(316, 403);
            this.dataGridView79.Name = "dataGridView79";
            this.dataGridView79.Size = new System.Drawing.Size(158, 47);
            this.dataGridView79.TabIndex = 852;
            // 
            // dataGridView78
            // 
            this.dataGridView78.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView78.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView78.Location = new System.Drawing.Point(673, 366);
            this.dataGridView78.Name = "dataGridView78";
            this.dataGridView78.Size = new System.Drawing.Size(76, 41);
            this.dataGridView78.TabIndex = 851;
            // 
            // dataGridView77
            // 
            this.dataGridView77.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView77.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView77.Location = new System.Drawing.Point(609, 367);
            this.dataGridView77.Name = "dataGridView77";
            this.dataGridView77.Size = new System.Drawing.Size(69, 40);
            this.dataGridView77.TabIndex = 850;
            // 
            // dataGridView76
            // 
            this.dataGridView76.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView76.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView76.Location = new System.Drawing.Point(533, 367);
            this.dataGridView76.Name = "dataGridView76";
            this.dataGridView76.Size = new System.Drawing.Size(81, 40);
            this.dataGridView76.TabIndex = 849;
            // 
            // dataGridView75
            // 
            this.dataGridView75.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView75.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView75.Location = new System.Drawing.Point(470, 367);
            this.dataGridView75.Name = "dataGridView75";
            this.dataGridView75.Size = new System.Drawing.Size(72, 40);
            this.dataGridView75.TabIndex = 848;
            // 
            // dataGridView74
            // 
            this.dataGridView74.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView74.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView74.Location = new System.Drawing.Point(316, 367);
            this.dataGridView74.Name = "dataGridView74";
            this.dataGridView74.Size = new System.Drawing.Size(158, 40);
            this.dataGridView74.TabIndex = 847;
            // 
            // dataGridView73
            // 
            this.dataGridView73.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView73.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView73.Location = new System.Drawing.Point(675, 331);
            this.dataGridView73.Name = "dataGridView73";
            this.dataGridView73.Size = new System.Drawing.Size(74, 45);
            this.dataGridView73.TabIndex = 846;
            // 
            // dataGridView72
            // 
            this.dataGridView72.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView72.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView72.Location = new System.Drawing.Point(611, 331);
            this.dataGridView72.Name = "dataGridView72";
            this.dataGridView72.Size = new System.Drawing.Size(67, 45);
            this.dataGridView72.TabIndex = 845;
            // 
            // dataGridView71
            // 
            this.dataGridView71.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView71.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView71.Location = new System.Drawing.Point(533, 331);
            this.dataGridView71.Name = "dataGridView71";
            this.dataGridView71.Size = new System.Drawing.Size(81, 45);
            this.dataGridView71.TabIndex = 844;
            // 
            // dataGridView70
            // 
            this.dataGridView70.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView70.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView70.Location = new System.Drawing.Point(470, 331);
            this.dataGridView70.Name = "dataGridView70";
            this.dataGridView70.Size = new System.Drawing.Size(72, 45);
            this.dataGridView70.TabIndex = 843;
            // 
            // dataGridView69
            // 
            this.dataGridView69.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView69.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView69.Location = new System.Drawing.Point(316, 331);
            this.dataGridView69.Name = "dataGridView69";
            this.dataGridView69.Size = new System.Drawing.Size(158, 45);
            this.dataGridView69.TabIndex = 842;
            // 
            // dataGridView68
            // 
            this.dataGridView68.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView68.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView68.Location = new System.Drawing.Point(675, 288);
            this.dataGridView68.Name = "dataGridView68";
            this.dataGridView68.Size = new System.Drawing.Size(74, 48);
            this.dataGridView68.TabIndex = 841;
            // 
            // dataGridView67
            // 
            this.dataGridView67.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView67.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView67.Location = new System.Drawing.Point(611, 288);
            this.dataGridView67.Name = "dataGridView67";
            this.dataGridView67.Size = new System.Drawing.Size(67, 64);
            this.dataGridView67.TabIndex = 840;
            // 
            // dataGridView66
            // 
            this.dataGridView66.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView66.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView66.Location = new System.Drawing.Point(533, 288);
            this.dataGridView66.Name = "dataGridView66";
            this.dataGridView66.Size = new System.Drawing.Size(83, 62);
            this.dataGridView66.TabIndex = 839;
            // 
            // dataGridView65
            // 
            this.dataGridView65.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView65.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView65.Location = new System.Drawing.Point(470, 288);
            this.dataGridView65.Name = "dataGridView65";
            this.dataGridView65.Size = new System.Drawing.Size(72, 61);
            this.dataGridView65.TabIndex = 838;
            // 
            // dataGridView64
            // 
            this.dataGridView64.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView64.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView64.Location = new System.Drawing.Point(316, 288);
            this.dataGridView64.Name = "dataGridView64";
            this.dataGridView64.Size = new System.Drawing.Size(158, 61);
            this.dataGridView64.TabIndex = 837;
            // 
            // dataGridView63
            // 
            this.dataGridView63.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView63.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView63.Location = new System.Drawing.Point(675, 256);
            this.dataGridView63.Name = "dataGridView63";
            this.dataGridView63.Size = new System.Drawing.Size(74, 37);
            this.dataGridView63.TabIndex = 836;
            // 
            // dataGridView62
            // 
            this.dataGridView62.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView62.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView62.Location = new System.Drawing.Point(611, 256);
            this.dataGridView62.Name = "dataGridView62";
            this.dataGridView62.Size = new System.Drawing.Size(67, 37);
            this.dataGridView62.TabIndex = 835;
            // 
            // dataGridView61
            // 
            this.dataGridView61.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView61.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView61.Location = new System.Drawing.Point(533, 256);
            this.dataGridView61.Name = "dataGridView61";
            this.dataGridView61.Size = new System.Drawing.Size(83, 37);
            this.dataGridView61.TabIndex = 834;
            // 
            // dataGridView60
            // 
            this.dataGridView60.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView60.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView60.Location = new System.Drawing.Point(470, 256);
            this.dataGridView60.Name = "dataGridView60";
            this.dataGridView60.Size = new System.Drawing.Size(72, 37);
            this.dataGridView60.TabIndex = 833;
            // 
            // dataGridView59
            // 
            this.dataGridView59.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView59.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView59.Location = new System.Drawing.Point(316, 256);
            this.dataGridView59.Name = "dataGridView59";
            this.dataGridView59.Size = new System.Drawing.Size(158, 53);
            this.dataGridView59.TabIndex = 832;
            // 
            // dataGridView58
            // 
            this.dataGridView58.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView58.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView58.Location = new System.Drawing.Point(675, 204);
            this.dataGridView58.Name = "dataGridView58";
            this.dataGridView58.Size = new System.Drawing.Size(74, 53);
            this.dataGridView58.TabIndex = 831;
            // 
            // dataGridView57
            // 
            this.dataGridView57.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView57.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView57.Location = new System.Drawing.Point(611, 204);
            this.dataGridView57.Name = "dataGridView57";
            this.dataGridView57.Size = new System.Drawing.Size(67, 53);
            this.dataGridView57.TabIndex = 830;
            // 
            // dataGridView56
            // 
            this.dataGridView56.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView56.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView56.Location = new System.Drawing.Point(533, 204);
            this.dataGridView56.Name = "dataGridView56";
            this.dataGridView56.Size = new System.Drawing.Size(83, 53);
            this.dataGridView56.TabIndex = 829;
            // 
            // dataGridView55
            // 
            this.dataGridView55.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView55.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView55.Location = new System.Drawing.Point(470, 204);
            this.dataGridView55.Name = "dataGridView55";
            this.dataGridView55.Size = new System.Drawing.Size(72, 53);
            this.dataGridView55.TabIndex = 828;
            // 
            // dataGridView54
            // 
            this.dataGridView54.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView54.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView54.Location = new System.Drawing.Point(316, 204);
            this.dataGridView54.Name = "dataGridView54";
            this.dataGridView54.Size = new System.Drawing.Size(158, 53);
            this.dataGridView54.TabIndex = 827;
            // 
            // dataGridView53
            // 
            this.dataGridView53.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView53.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView53.Location = new System.Drawing.Point(675, 172);
            this.dataGridView53.Name = "dataGridView53";
            this.dataGridView53.Size = new System.Drawing.Size(74, 46);
            this.dataGridView53.TabIndex = 826;
            // 
            // dataGridView52
            // 
            this.dataGridView52.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView52.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView52.Location = new System.Drawing.Point(611, 172);
            this.dataGridView52.Name = "dataGridView52";
            this.dataGridView52.Size = new System.Drawing.Size(67, 46);
            this.dataGridView52.TabIndex = 825;
            // 
            // dataGridView51
            // 
            this.dataGridView51.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView51.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView51.Location = new System.Drawing.Point(533, 172);
            this.dataGridView51.Name = "dataGridView51";
            this.dataGridView51.Size = new System.Drawing.Size(83, 46);
            this.dataGridView51.TabIndex = 824;
            // 
            // dataGridView50
            // 
            this.dataGridView50.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView50.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView50.Location = new System.Drawing.Point(470, 172);
            this.dataGridView50.Name = "dataGridView50";
            this.dataGridView50.Size = new System.Drawing.Size(72, 45);
            this.dataGridView50.TabIndex = 823;
            // 
            // dataGridView49
            // 
            this.dataGridView49.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView49.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView49.Location = new System.Drawing.Point(316, 172);
            this.dataGridView49.Name = "dataGridView49";
            this.dataGridView49.Size = new System.Drawing.Size(158, 45);
            this.dataGridView49.TabIndex = 822;
            // 
            // dataGridView48
            // 
            this.dataGridView48.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView48.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView48.Location = new System.Drawing.Point(675, 133);
            this.dataGridView48.Name = "dataGridView48";
            this.dataGridView48.Size = new System.Drawing.Size(74, 40);
            this.dataGridView48.TabIndex = 821;
            // 
            // dataGridView47
            // 
            this.dataGridView47.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView47.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView47.Location = new System.Drawing.Point(611, 133);
            this.dataGridView47.Name = "dataGridView47";
            this.dataGridView47.Size = new System.Drawing.Size(67, 40);
            this.dataGridView47.TabIndex = 820;
            // 
            // dataGridView46
            // 
            this.dataGridView46.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView46.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView46.Location = new System.Drawing.Point(533, 133);
            this.dataGridView46.Name = "dataGridView46";
            this.dataGridView46.Size = new System.Drawing.Size(81, 40);
            this.dataGridView46.TabIndex = 819;
            // 
            // dataGridView45
            // 
            this.dataGridView45.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView45.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView45.Location = new System.Drawing.Point(470, 133);
            this.dataGridView45.Name = "dataGridView45";
            this.dataGridView45.Size = new System.Drawing.Size(72, 40);
            this.dataGridView45.TabIndex = 818;
            // 
            // dataGridView44
            // 
            this.dataGridView44.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView44.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView44.Location = new System.Drawing.Point(316, 133);
            this.dataGridView44.Name = "dataGridView44";
            this.dataGridView44.Size = new System.Drawing.Size(158, 40);
            this.dataGridView44.TabIndex = 817;
            // 
            // dataGridView43
            // 
            this.dataGridView43.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView43.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView43.Location = new System.Drawing.Point(675, 90);
            this.dataGridView43.Name = "dataGridView43";
            this.dataGridView43.Size = new System.Drawing.Size(74, 46);
            this.dataGridView43.TabIndex = 816;
            // 
            // dataGridView42
            // 
            this.dataGridView42.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView42.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView42.Location = new System.Drawing.Point(611, 91);
            this.dataGridView42.Name = "dataGridView42";
            this.dataGridView42.Size = new System.Drawing.Size(67, 45);
            this.dataGridView42.TabIndex = 815;
            // 
            // dataGridView41
            // 
            this.dataGridView41.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView41.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView41.Location = new System.Drawing.Point(533, 90);
            this.dataGridView41.Name = "dataGridView41";
            this.dataGridView41.Size = new System.Drawing.Size(81, 46);
            this.dataGridView41.TabIndex = 814;
            // 
            // dataGridView40
            // 
            this.dataGridView40.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView40.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView40.Location = new System.Drawing.Point(470, 91);
            this.dataGridView40.Name = "dataGridView40";
            this.dataGridView40.Size = new System.Drawing.Size(72, 45);
            this.dataGridView40.TabIndex = 813;
            // 
            // dataGridView39
            // 
            this.dataGridView39.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView39.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView39.Location = new System.Drawing.Point(316, 91);
            this.dataGridView39.Name = "dataGridView39";
            this.dataGridView39.Size = new System.Drawing.Size(158, 45);
            this.dataGridView39.TabIndex = 812;
            // 
            // dataGridView38
            // 
            this.dataGridView38.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView38.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView38.Location = new System.Drawing.Point(675, 61);
            this.dataGridView38.Name = "dataGridView38";
            this.dataGridView38.Size = new System.Drawing.Size(74, 43);
            this.dataGridView38.TabIndex = 811;
            // 
            // dataGridView37
            // 
            this.dataGridView37.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView37.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView37.Location = new System.Drawing.Point(611, 61);
            this.dataGridView37.Name = "dataGridView37";
            this.dataGridView37.Size = new System.Drawing.Size(67, 43);
            this.dataGridView37.TabIndex = 810;
            // 
            // dataGridView36
            // 
            this.dataGridView36.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView36.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView36.Location = new System.Drawing.Point(533, 61);
            this.dataGridView36.Name = "dataGridView36";
            this.dataGridView36.Size = new System.Drawing.Size(83, 43);
            this.dataGridView36.TabIndex = 809;
            // 
            // dataGridView35
            // 
            this.dataGridView35.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView35.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView35.Location = new System.Drawing.Point(470, 61);
            this.dataGridView35.Name = "dataGridView35";
            this.dataGridView35.Size = new System.Drawing.Size(72, 43);
            this.dataGridView35.TabIndex = 808;
            // 
            // dataGridView34
            // 
            this.dataGridView34.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView34.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView34.Location = new System.Drawing.Point(316, 61);
            this.dataGridView34.Name = "dataGridView34";
            this.dataGridView34.Size = new System.Drawing.Size(158, 43);
            this.dataGridView34.TabIndex = 807;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(121, 515);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(23, 13);
            this.label61.TabIndex = 806;
            this.label61.Text = "T.a";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(105, 75);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(64, 13);
            this.label60.TabIndex = 805;
            this.label60.Text = "Date 1 coss";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(107, 385);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(50, 13);
            this.label59.TabIndex = 804;
            this.label59.Text = "Oedénes";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(117, 262);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(27, 13);
            this.label56.TabIndex = 803;
            this.label56.Text = "BCF";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(105, 613);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(73, 13);
            this.label51.TabIndex = 802;
            this.label51.Text = "Taille < 1.50m";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(103, 428);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(61, 13);
            this.label47.TabIndex = 801;
            this.label47.Text = "Albuminurie";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(132, 565);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(32, 13);
            this.label45.TabIndex = 800;
            this.label45.Text = "poids";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(108, 297);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(66, 13);
            this.label44.TabIndex = 799;
            this.label44.Text = "Présentation";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(55, 339);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(177, 13);
            this.label43.TabIndex = 798;
            this.label43.Text = "Portes liquidennes (sang, eaux, pas)";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(105, 218);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(91, 13);
            this.label42.TabIndex = 797;
            this.label42.Text = "Mvts foetaux BCF";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(98, 147);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(131, 13);
            this.label40.TabIndex = 796;
            this.label40.Text = "Mois/ semaines accomplis";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(107, 464);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(57, 13);
            this.label38.TabIndex = 795;
            this.label38.Text = "Glucosurie";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(94, 182);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(80, 13);
            this.label37.TabIndex = 794;
            this.label37.Text = "Hauteur utérine";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(105, 98);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(82, 13);
            this.label36.TabIndex = 793;
            this.label36.Text = "Conjonctive/Hb";
            // 
            // dataGridView33
            // 
            this.dataGridView33.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView33.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView33.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView33.Location = new System.Drawing.Point(276, 91);
            this.dataGridView33.Name = "dataGridView33";
            this.dataGridView33.Size = new System.Drawing.Size(43, 45);
            this.dataGridView33.TabIndex = 792;
            // 
            // dataGridView32
            // 
            this.dataGridView32.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView32.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView32.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView32.Location = new System.Drawing.Point(276, 247);
            this.dataGridView32.Name = "dataGridView32";
            this.dataGridView32.Size = new System.Drawing.Size(43, 46);
            this.dataGridView32.TabIndex = 791;
            // 
            // dataGridView31
            // 
            this.dataGridView31.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView31.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView31.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView31.Location = new System.Drawing.Point(276, 133);
            this.dataGridView31.Name = "dataGridView31";
            this.dataGridView31.Size = new System.Drawing.Size(43, 40);
            this.dataGridView31.TabIndex = 790;
            // 
            // dataGridView30
            // 
            this.dataGridView30.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView30.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView30.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView30.Location = new System.Drawing.Point(276, 172);
            this.dataGridView30.Name = "dataGridView30";
            this.dataGridView30.Size = new System.Drawing.Size(43, 32);
            this.dataGridView30.TabIndex = 789;
            // 
            // dataGridView29
            // 
            this.dataGridView29.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView29.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView29.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView29.Location = new System.Drawing.Point(276, 204);
            this.dataGridView29.Name = "dataGridView29";
            this.dataGridView29.Size = new System.Drawing.Size(43, 45);
            this.dataGridView29.TabIndex = 788;
            // 
            // dataGridView28
            // 
            this.dataGridView28.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView28.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView28.Location = new System.Drawing.Point(3, 247);
            this.dataGridView28.Name = "dataGridView28";
            this.dataGridView28.Size = new System.Drawing.Size(277, 46);
            this.dataGridView28.TabIndex = 787;
            // 
            // dataGridView27
            // 
            this.dataGridView27.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView27.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView27.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView27.Location = new System.Drawing.Point(276, 331);
            this.dataGridView27.Name = "dataGridView27";
            this.dataGridView27.Size = new System.Drawing.Size(43, 40);
            this.dataGridView27.TabIndex = 786;
            // 
            // dataGridView26
            // 
            this.dataGridView26.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView26.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView26.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView26.Location = new System.Drawing.Point(276, 280);
            this.dataGridView26.Name = "dataGridView26";
            this.dataGridView26.Size = new System.Drawing.Size(43, 56);
            this.dataGridView26.TabIndex = 785;
            // 
            // dataGridView25
            // 
            this.dataGridView25.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView25.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView25.Location = new System.Drawing.Point(276, 366);
            this.dataGridView25.Name = "dataGridView25";
            this.dataGridView25.Size = new System.Drawing.Size(43, 40);
            this.dataGridView25.TabIndex = 784;
            // 
            // dataGridView24
            // 
            this.dataGridView24.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView24.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView24.Location = new System.Drawing.Point(3, 172);
            this.dataGridView24.Name = "dataGridView24";
            this.dataGridView24.Size = new System.Drawing.Size(277, 32);
            this.dataGridView24.TabIndex = 783;
            // 
            // dataGridView23
            // 
            this.dataGridView23.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView23.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView23.Location = new System.Drawing.Point(3, 203);
            this.dataGridView23.Name = "dataGridView23";
            this.dataGridView23.Size = new System.Drawing.Size(277, 45);
            this.dataGridView23.TabIndex = 782;
            // 
            // dataGridView22
            // 
            this.dataGridView22.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView22.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView22.Location = new System.Drawing.Point(3, 331);
            this.dataGridView22.Name = "dataGridView22";
            this.dataGridView22.Size = new System.Drawing.Size(277, 40);
            this.dataGridView22.TabIndex = 781;
            // 
            // dataGridView21
            // 
            this.dataGridView21.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView21.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView21.Location = new System.Drawing.Point(3, 367);
            this.dataGridView21.Name = "dataGridView21";
            this.dataGridView21.Size = new System.Drawing.Size(277, 40);
            this.dataGridView21.TabIndex = 780;
            // 
            // dataGridView20
            // 
            this.dataGridView20.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView20.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView20.Location = new System.Drawing.Point(276, 491);
            this.dataGridView20.Name = "dataGridView20";
            this.dataGridView20.Size = new System.Drawing.Size(43, 55);
            this.dataGridView20.TabIndex = 779;
            // 
            // dataGridView19
            // 
            this.dataGridView19.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView19.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView19.Location = new System.Drawing.Point(276, 542);
            this.dataGridView19.Name = "dataGridView19";
            this.dataGridView19.Size = new System.Drawing.Size(43, 52);
            this.dataGridView19.TabIndex = 778;
            // 
            // dataGridView18
            // 
            this.dataGridView18.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView18.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView18.Location = new System.Drawing.Point(3, 542);
            this.dataGridView18.Name = "dataGridView18";
            this.dataGridView18.Size = new System.Drawing.Size(277, 52);
            this.dataGridView18.TabIndex = 777;
            // 
            // dataGridView17
            // 
            this.dataGridView17.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView17.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView17.Location = new System.Drawing.Point(276, 590);
            this.dataGridView17.Name = "dataGridView17";
            this.dataGridView17.Size = new System.Drawing.Size(43, 51);
            this.dataGridView17.TabIndex = 776;
            // 
            // dataGridView16
            // 
            this.dataGridView16.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView16.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView16.Location = new System.Drawing.Point(276, 403);
            this.dataGridView16.Name = "dataGridView16";
            this.dataGridView16.Size = new System.Drawing.Size(43, 47);
            this.dataGridView16.TabIndex = 775;
            // 
            // dataGridView15
            // 
            this.dataGridView15.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView15.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView15.Location = new System.Drawing.Point(3, 491);
            this.dataGridView15.Name = "dataGridView15";
            this.dataGridView15.Size = new System.Drawing.Size(277, 54);
            this.dataGridView15.TabIndex = 774;
            // 
            // dataGridView14
            // 
            this.dataGridView14.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView14.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView14.Location = new System.Drawing.Point(3, 401);
            this.dataGridView14.Name = "dataGridView14";
            this.dataGridView14.Size = new System.Drawing.Size(277, 49);
            this.dataGridView14.TabIndex = 773;
            // 
            // dataGridView13
            // 
            this.dataGridView13.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView13.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView13.Location = new System.Drawing.Point(276, 444);
            this.dataGridView13.Name = "dataGridView13";
            this.dataGridView13.Size = new System.Drawing.Size(43, 49);
            this.dataGridView13.TabIndex = 772;
            // 
            // dataGridView12
            // 
            this.dataGridView12.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView12.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView12.Location = new System.Drawing.Point(3, 133);
            this.dataGridView12.Name = "dataGridView12";
            this.dataGridView12.Size = new System.Drawing.Size(277, 40);
            this.dataGridView12.TabIndex = 771;
            // 
            // dataGridView11
            // 
            this.dataGridView11.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView11.Location = new System.Drawing.Point(3, 590);
            this.dataGridView11.Name = "dataGridView11";
            this.dataGridView11.Size = new System.Drawing.Size(277, 51);
            this.dataGridView11.TabIndex = 770;
            // 
            // dataGridView10
            // 
            this.dataGridView10.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView10.Location = new System.Drawing.Point(3, 444);
            this.dataGridView10.Name = "dataGridView10";
            this.dataGridView10.Size = new System.Drawing.Size(277, 49);
            this.dataGridView10.TabIndex = 769;
            // 
            // dataGridView9
            // 
            this.dataGridView9.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView9.Location = new System.Drawing.Point(3, 280);
            this.dataGridView9.Name = "dataGridView9";
            this.dataGridView9.Size = new System.Drawing.Size(277, 56);
            this.dataGridView9.TabIndex = 768;
            // 
            // dataGridView8
            // 
            this.dataGridView8.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Location = new System.Drawing.Point(3, 91);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.Size = new System.Drawing.Size(277, 45);
            this.dataGridView8.TabIndex = 767;
            // 
            // dataGridView7
            // 
            this.dataGridView7.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView7.Location = new System.Drawing.Point(276, 61);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.Size = new System.Drawing.Size(43, 44);
            this.dataGridView7.TabIndex = 766;
            // 
            // dataGridView6
            // 
            this.dataGridView6.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(3, 61);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.Size = new System.Drawing.Size(277, 43);
            this.dataGridView6.TabIndex = 765;
            // 
            // dataGridView5
            // 
            this.dataGridView5.AllowUserToAddRows = false;
            this.dataGridView5.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column3,
            this.Column4});
            this.dataGridView5.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridView5.Location = new System.Drawing.Point(3, 61);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(746, 598);
            this.dataGridView5.TabIndex = 764;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "D.D.R :";
            this.Column3.Name = "Column3";
            this.Column3.Width = 300;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Date prévue Aee :";
            this.Column4.Name = "Column4";
            this.Column4.Width = 450;
            // 
            // maskedTextBox11
            // 
            this.maskedTextBox11.Location = new System.Drawing.Point(844, 722);
            this.maskedTextBox11.Name = "maskedTextBox11";
            this.maskedTextBox11.Size = new System.Drawing.Size(505, 20);
            this.maskedTextBox11.TabIndex = 763;
            // 
            // maskedTextBox10
            // 
            this.maskedTextBox10.Location = new System.Drawing.Point(774, 695);
            this.maskedTextBox10.Name = "maskedTextBox10";
            this.maskedTextBox10.Size = new System.Drawing.Size(575, 20);
            this.maskedTextBox10.TabIndex = 762;
            // 
            // maskedTextBox9
            // 
            this.maskedTextBox9.Location = new System.Drawing.Point(865, 669);
            this.maskedTextBox9.Name = "maskedTextBox9";
            this.maskedTextBox9.Size = new System.Drawing.Size(484, 20);
            this.maskedTextBox9.TabIndex = 761;
            // 
            // maskedTextBox8
            // 
            this.maskedTextBox8.Location = new System.Drawing.Point(903, 645);
            this.maskedTextBox8.Name = "maskedTextBox8";
            this.maskedTextBox8.Size = new System.Drawing.Size(447, 20);
            this.maskedTextBox8.TabIndex = 760;
            // 
            // maskedTextBox7
            // 
            this.maskedTextBox7.Location = new System.Drawing.Point(775, 622);
            this.maskedTextBox7.Name = "maskedTextBox7";
            this.maskedTextBox7.Size = new System.Drawing.Size(575, 20);
            this.maskedTextBox7.TabIndex = 759;
            // 
            // maskedTextBox6
            // 
            this.maskedTextBox6.Location = new System.Drawing.Point(914, 599);
            this.maskedTextBox6.Name = "maskedTextBox6";
            this.maskedTextBox6.Size = new System.Drawing.Size(436, 20);
            this.maskedTextBox6.TabIndex = 758;
            // 
            // maskedTextBox5
            // 
            this.maskedTextBox5.Location = new System.Drawing.Point(773, 573);
            this.maskedTextBox5.Name = "maskedTextBox5";
            this.maskedTextBox5.Size = new System.Drawing.Size(577, 20);
            this.maskedTextBox5.TabIndex = 757;
            // 
            // maskedTextBox4
            // 
            this.maskedTextBox4.Location = new System.Drawing.Point(894, 547);
            this.maskedTextBox4.Name = "maskedTextBox4";
            this.maskedTextBox4.Size = new System.Drawing.Size(456, 20);
            this.maskedTextBox4.TabIndex = 756;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(770, 725);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(68, 13);
            this.label35.TabIndex = 755;
            this.label35.Text = "-Décision :";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(772, 672);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(81, 13);
            this.label34.TabIndex = 754;
            this.label34.Text = "-Conclusion :";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(772, 648);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(125, 13);
            this.label33.TabIndex = 753;
            this.label33.Text = "-Autres observation :";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(770, 604);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(138, 13);
            this.label32.TabIndex = 752;
            this.label32.Text = "-Examen paracliniques:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(772, 550);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(117, 13);
            this.label31.TabIndex = 751;
            this.label31.Text = "-Examen physique :";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(770, 525);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(136, 13);
            this.label30.TabIndex = 750;
            this.label30.Text = "IV. Suivi à la maternité";
            // 
            // dataGridView4
            // 
            this.dataGridView4.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(762, 512);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(599, 232);
            this.dataGridView4.TabIndex = 749;
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.Location = new System.Drawing.Point(899, 390);
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Size = new System.Drawing.Size(140, 20);
            this.maskedTextBox3.TabIndex = 748;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Location = new System.Drawing.Point(1335, 70);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(15, 14);
            this.checkBox24.TabIndex = 747;
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Location = new System.Drawing.Point(1335, 96);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(15, 14);
            this.checkBox23.TabIndex = 746;
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Location = new System.Drawing.Point(1335, 134);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(15, 14);
            this.checkBox22.TabIndex = 745;
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Location = new System.Drawing.Point(1335, 164);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(15, 14);
            this.checkBox21.TabIndex = 744;
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Location = new System.Drawing.Point(1335, 195);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(15, 14);
            this.checkBox20.TabIndex = 743;
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Location = new System.Drawing.Point(1335, 458);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(15, 14);
            this.checkBox19.TabIndex = 742;
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Location = new System.Drawing.Point(1044, 256);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(15, 14);
            this.checkBox18.TabIndex = 741;
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Location = new System.Drawing.Point(1239, 256);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(15, 14);
            this.checkBox17.TabIndex = 740;
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Location = new System.Drawing.Point(1099, 353);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(15, 14);
            this.checkBox16.TabIndex = 739;
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Location = new System.Drawing.Point(934, 322);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(15, 14);
            this.checkBox15.TabIndex = 738;
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(1335, 353);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(15, 14);
            this.checkBox14.TabIndex = 737;
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(985, 458);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(15, 14);
            this.checkBox13.TabIndex = 736;
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(949, 134);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(15, 14);
            this.checkBox12.TabIndex = 735;
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(934, 352);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(15, 14);
            this.checkBox11.TabIndex = 734;
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(1155, 458);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(15, 14);
            this.checkBox10.TabIndex = 733;
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(934, 492);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(15, 14);
            this.checkBox9.TabIndex = 732;
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(1335, 393);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(15, 14);
            this.checkBox8.TabIndex = 731;
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(1155, 491);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(15, 14);
            this.checkBox7.TabIndex = 730;
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(1335, 256);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(15, 14);
            this.checkBox6.TabIndex = 729;
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(1335, 296);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(15, 14);
            this.checkBox5.TabIndex = 728;
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(1239, 352);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(15, 14);
            this.checkBox4.TabIndex = 727;
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(1335, 223);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(15, 14);
            this.checkBox3.TabIndex = 726;
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(1335, 423);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(15, 14);
            this.checkBox2.TabIndex = 725;
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(856, 222);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 724;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Location = new System.Drawing.Point(883, 93);
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(175, 20);
            this.maskedTextBox2.TabIndex = 723;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(824, 67);
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(84, 20);
            this.maskedTextBox1.TabIndex = 722;
            // 
            // dataGridView3
            // 
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(1301, 51);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(28, 487);
            this.dataGridView3.TabIndex = 721;
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView2.Location = new System.Drawing.Point(1301, 51);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(60, 487);
            this.dataGridView2.TabIndex = 720;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(1077, 492);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(53, 13);
            this.label29.TabIndex = 719;
            this.label29.Text = "Irrégulière";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(1060, 393);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(153, 13);
            this.label28.TabIndex = 718;
            this.label28.Text = "T.A . > 14 et minima 9 oou plus";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(1020, 296);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(195, 13);
            this.label27.TabIndex = 717;
            this.label27.Text = "Taille < 1 m 50 et promontoire acceuible";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(774, 459);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(108, 13);
            this.label26.TabIndex = 716;
            this.label26.Text = "Contractios ulterines :";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(1179, 223);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(34, 13);
            this.label25.TabIndex = 715;
            this.label25.Text = "Siège";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(937, 459);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(27, 13);
            this.label24.TabIndex = 714;
            this.label24.Text = "Non";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(775, 492);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(133, 13);
            this.label23.TabIndex = 713;
            this.label23.Text = "Surface utérine : Régulière";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(1161, 256);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(52, 13);
            this.label22.TabIndex = 712;
            this.label22.Text = "Non fixée";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(775, 323);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(67, 13);
            this.label21.TabIndex = 711;
            this.label21.Text = "Oedèmes :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(1107, 459);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(23, 13);
            this.label20.TabIndex = 710;
            this.label20.Text = "Oui";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(863, 393);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(30, 13);
            this.label19.TabIndex = 709;
            this.label19.Text = "T.A :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(777, 223);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 13);
            this.label18.TabIndex = 708;
            this.label18.Text = "Si Nullipare";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(1012, 353);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 13);
            this.label17.TabIndex = 707;
            this.label17.Text = "Alb. négative";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(1172, 353);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 13);
            this.label16.TabIndex = 706;
            this.label16.Text = "positive";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(863, 323);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(45, 13);
            this.label15.TabIndex = 705;
            this.label15.Text = "Absents";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(777, 424);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(210, 13);
            this.label14.TabIndex = 704;
            this.label14.Text = "Perte liquidennes : sang, Eaux, Pus, Autres";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(863, 353);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(43, 13);
            this.label13.TabIndex = 703;
            this.label13.Text = "Présent";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(966, 256);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 13);
            this.label12.TabIndex = 702;
            this.label12.Text = "Tête fixée";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(1143, 195);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(70, 13);
            this.label11.TabIndex = 701;
            this.label11.Text = "Transverse";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(775, 195);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(78, 13);
            this.label10.TabIndex = 700;
            this.label10.Text = "Présentation";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1071, 164);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(144, 13);
            this.label9.TabIndex = 699;
            this.label9.Text = "Si BCF < 120/min et 160/min";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(880, 134);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 13);
            this.label8.TabIndex = 698;
            this.label8.Text = "Présents";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(774, 134);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 13);
            this.label7.TabIndex = 697;
            this.label7.Text = "Bruiits fortaux :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(1143, 134);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 696;
            this.label6.Text = "Si Bc absents";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(1114, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 13);
            this.label5.TabIndex = 695;
            this.label5.Text = "Si plus de 30 cm";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(1012, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(203, 13);
            this.label4.TabIndex = 694;
            this.label4.Text = "Si Hb <7 g% ou Hb moins de 50 % ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(774, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 13);
            this.label3.TabIndex = 693;
            this.label3.Text = "Hauteur utérine :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(774, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 692;
            this.label2.Text = "Conj. :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(774, 51);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(226, 13);
            this.label1.TabIndex = 691;
            this.label1.Text = "Voir décision de l\'eumen pour féf à la maternité";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.dataGridView1.Location = new System.Drawing.Point(762, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(599, 536);
            this.dataGridView1.TabIndex = 681;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Consultation (8 mois) 9 mois - date :";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 500;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "R.D.V/Référée à la CPN de la Mat";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 60;
            // 
            // Suivi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.maskedTextBox19);
            this.Controls.Add(this.maskedTextBox18);
            this.Controls.Add(this.maskedTextBox17);
            this.Controls.Add(this.maskedTextBox16);
            this.Controls.Add(this.maskedTextBox15);
            this.Controls.Add(this.maskedTextBox14);
            this.Controls.Add(this.maskedTextBox13);
            this.Controls.Add(this.maskedTextBox12);
            this.Controls.Add(this.label79);
            this.Controls.Add(this.label78);
            this.Controls.Add(this.label77);
            this.Controls.Add(this.label76);
            this.Controls.Add(this.label75);
            this.Controls.Add(this.label74);
            this.Controls.Add(this.label73);
            this.Controls.Add(this.label72);
            this.Controls.Add(this.dataGridView104);
            this.Controls.Add(this.label71);
            this.Controls.Add(this.label70);
            this.Controls.Add(this.label69);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.label66);
            this.Controls.Add(this.label65);
            this.Controls.Add(this.label64);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label63);
            this.Controls.Add(this.label62);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.dataGridView103);
            this.Controls.Add(this.dataGridView102);
            this.Controls.Add(this.dataGridView101);
            this.Controls.Add(this.dataGridView100);
            this.Controls.Add(this.dataGridView99);
            this.Controls.Add(this.dataGridView98);
            this.Controls.Add(this.dataGridView97);
            this.Controls.Add(this.dataGridView96);
            this.Controls.Add(this.dataGridView95);
            this.Controls.Add(this.dataGridView94);
            this.Controls.Add(this.dataGridView93);
            this.Controls.Add(this.dataGridView92);
            this.Controls.Add(this.dataGridView91);
            this.Controls.Add(this.dataGridView90);
            this.Controls.Add(this.dataGridView89);
            this.Controls.Add(this.dataGridView88);
            this.Controls.Add(this.dataGridView87);
            this.Controls.Add(this.dataGridView86);
            this.Controls.Add(this.dataGridView85);
            this.Controls.Add(this.dataGridView84);
            this.Controls.Add(this.dataGridView83);
            this.Controls.Add(this.dataGridView82);
            this.Controls.Add(this.dataGridView81);
            this.Controls.Add(this.dataGridView80);
            this.Controls.Add(this.dataGridView79);
            this.Controls.Add(this.dataGridView78);
            this.Controls.Add(this.dataGridView77);
            this.Controls.Add(this.dataGridView76);
            this.Controls.Add(this.dataGridView75);
            this.Controls.Add(this.dataGridView74);
            this.Controls.Add(this.dataGridView73);
            this.Controls.Add(this.dataGridView72);
            this.Controls.Add(this.dataGridView71);
            this.Controls.Add(this.dataGridView70);
            this.Controls.Add(this.dataGridView69);
            this.Controls.Add(this.dataGridView68);
            this.Controls.Add(this.dataGridView67);
            this.Controls.Add(this.dataGridView66);
            this.Controls.Add(this.dataGridView65);
            this.Controls.Add(this.dataGridView64);
            this.Controls.Add(this.dataGridView63);
            this.Controls.Add(this.dataGridView62);
            this.Controls.Add(this.dataGridView61);
            this.Controls.Add(this.dataGridView60);
            this.Controls.Add(this.dataGridView59);
            this.Controls.Add(this.dataGridView58);
            this.Controls.Add(this.dataGridView57);
            this.Controls.Add(this.dataGridView56);
            this.Controls.Add(this.dataGridView55);
            this.Controls.Add(this.dataGridView54);
            this.Controls.Add(this.dataGridView53);
            this.Controls.Add(this.dataGridView52);
            this.Controls.Add(this.dataGridView51);
            this.Controls.Add(this.dataGridView50);
            this.Controls.Add(this.dataGridView49);
            this.Controls.Add(this.dataGridView48);
            this.Controls.Add(this.dataGridView47);
            this.Controls.Add(this.dataGridView46);
            this.Controls.Add(this.dataGridView45);
            this.Controls.Add(this.dataGridView44);
            this.Controls.Add(this.dataGridView43);
            this.Controls.Add(this.dataGridView42);
            this.Controls.Add(this.dataGridView41);
            this.Controls.Add(this.dataGridView40);
            this.Controls.Add(this.dataGridView39);
            this.Controls.Add(this.dataGridView38);
            this.Controls.Add(this.dataGridView37);
            this.Controls.Add(this.dataGridView36);
            this.Controls.Add(this.dataGridView35);
            this.Controls.Add(this.dataGridView34);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.dataGridView33);
            this.Controls.Add(this.dataGridView32);
            this.Controls.Add(this.dataGridView31);
            this.Controls.Add(this.dataGridView30);
            this.Controls.Add(this.dataGridView29);
            this.Controls.Add(this.dataGridView28);
            this.Controls.Add(this.dataGridView27);
            this.Controls.Add(this.dataGridView26);
            this.Controls.Add(this.dataGridView25);
            this.Controls.Add(this.dataGridView24);
            this.Controls.Add(this.dataGridView23);
            this.Controls.Add(this.dataGridView22);
            this.Controls.Add(this.dataGridView21);
            this.Controls.Add(this.dataGridView20);
            this.Controls.Add(this.dataGridView19);
            this.Controls.Add(this.dataGridView18);
            this.Controls.Add(this.dataGridView17);
            this.Controls.Add(this.dataGridView16);
            this.Controls.Add(this.dataGridView15);
            this.Controls.Add(this.dataGridView14);
            this.Controls.Add(this.dataGridView13);
            this.Controls.Add(this.dataGridView12);
            this.Controls.Add(this.dataGridView11);
            this.Controls.Add(this.dataGridView10);
            this.Controls.Add(this.dataGridView9);
            this.Controls.Add(this.dataGridView8);
            this.Controls.Add(this.dataGridView7);
            this.Controls.Add(this.dataGridView6);
            this.Controls.Add(this.dataGridView5);
            this.Controls.Add(this.maskedTextBox11);
            this.Controls.Add(this.maskedTextBox10);
            this.Controls.Add(this.maskedTextBox9);
            this.Controls.Add(this.maskedTextBox8);
            this.Controls.Add(this.maskedTextBox7);
            this.Controls.Add(this.maskedTextBox6);
            this.Controls.Add(this.maskedTextBox5);
            this.Controls.Add(this.maskedTextBox4);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.dataGridView4);
            this.Controls.Add(this.maskedTextBox3);
            this.Controls.Add(this.checkBox24);
            this.Controls.Add(this.checkBox23);
            this.Controls.Add(this.checkBox22);
            this.Controls.Add(this.checkBox21);
            this.Controls.Add(this.checkBox20);
            this.Controls.Add(this.checkBox19);
            this.Controls.Add(this.checkBox18);
            this.Controls.Add(this.checkBox17);
            this.Controls.Add(this.checkBox16);
            this.Controls.Add(this.checkBox15);
            this.Controls.Add(this.checkBox14);
            this.Controls.Add(this.checkBox13);
            this.Controls.Add(this.checkBox12);
            this.Controls.Add(this.checkBox11);
            this.Controls.Add(this.checkBox10);
            this.Controls.Add(this.checkBox9);
            this.Controls.Add(this.checkBox8);
            this.Controls.Add(this.checkBox7);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.maskedTextBox2);
            this.Controls.Add(this.maskedTextBox1);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Suivi";
            this.Text = "Suivi";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView104)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView103)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView102)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView101)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView100)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView99)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView98)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView97)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView96)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView95)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView94)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView93)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView92)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView91)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView90)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView89)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView88)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView87)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView86)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView85)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView84)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView83)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView82)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView81)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView80)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView79)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView78)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView77)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView76)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView75)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView74)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView73)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView72)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView71)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView70)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView69)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView68)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView67)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView66)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView65)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView64)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView63)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView62)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView57)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox maskedTextBox19;
        private System.Windows.Forms.MaskedTextBox maskedTextBox18;
        private System.Windows.Forms.MaskedTextBox maskedTextBox17;
        private System.Windows.Forms.MaskedTextBox maskedTextBox16;
        private System.Windows.Forms.MaskedTextBox maskedTextBox15;
        private System.Windows.Forms.MaskedTextBox maskedTextBox14;
        private System.Windows.Forms.MaskedTextBox maskedTextBox13;
        private System.Windows.Forms.MaskedTextBox maskedTextBox12;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.DataGridView dataGridView104;
        private System.Windows.Forms.DataGridViewTextBoxColumn CLM;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.DataGridView dataGridView103;
        private System.Windows.Forms.DataGridView dataGridView102;
        private System.Windows.Forms.DataGridView dataGridView101;
        private System.Windows.Forms.DataGridView dataGridView100;
        private System.Windows.Forms.DataGridView dataGridView99;
        private System.Windows.Forms.DataGridView dataGridView98;
        private System.Windows.Forms.DataGridView dataGridView97;
        private System.Windows.Forms.DataGridView dataGridView96;
        private System.Windows.Forms.DataGridView dataGridView95;
        private System.Windows.Forms.DataGridView dataGridView94;
        private System.Windows.Forms.DataGridView dataGridView93;
        private System.Windows.Forms.DataGridView dataGridView92;
        private System.Windows.Forms.DataGridView dataGridView91;
        private System.Windows.Forms.DataGridView dataGridView90;
        private System.Windows.Forms.DataGridView dataGridView89;
        private System.Windows.Forms.DataGridView dataGridView88;
        private System.Windows.Forms.DataGridView dataGridView87;
        private System.Windows.Forms.DataGridView dataGridView86;
        private System.Windows.Forms.DataGridView dataGridView85;
        private System.Windows.Forms.DataGridView dataGridView84;
        private System.Windows.Forms.DataGridView dataGridView83;
        private System.Windows.Forms.DataGridView dataGridView82;
        private System.Windows.Forms.DataGridView dataGridView81;
        private System.Windows.Forms.DataGridView dataGridView80;
        private System.Windows.Forms.DataGridView dataGridView79;
        private System.Windows.Forms.DataGridView dataGridView78;
        private System.Windows.Forms.DataGridView dataGridView77;
        private System.Windows.Forms.DataGridView dataGridView76;
        private System.Windows.Forms.DataGridView dataGridView75;
        private System.Windows.Forms.DataGridView dataGridView74;
        private System.Windows.Forms.DataGridView dataGridView73;
        private System.Windows.Forms.DataGridView dataGridView72;
        private System.Windows.Forms.DataGridView dataGridView71;
        private System.Windows.Forms.DataGridView dataGridView70;
        private System.Windows.Forms.DataGridView dataGridView69;
        private System.Windows.Forms.DataGridView dataGridView68;
        private System.Windows.Forms.DataGridView dataGridView67;
        private System.Windows.Forms.DataGridView dataGridView66;
        private System.Windows.Forms.DataGridView dataGridView65;
        private System.Windows.Forms.DataGridView dataGridView64;
        private System.Windows.Forms.DataGridView dataGridView63;
        private System.Windows.Forms.DataGridView dataGridView62;
        private System.Windows.Forms.DataGridView dataGridView61;
        private System.Windows.Forms.DataGridView dataGridView60;
        private System.Windows.Forms.DataGridView dataGridView59;
        private System.Windows.Forms.DataGridView dataGridView58;
        private System.Windows.Forms.DataGridView dataGridView57;
        private System.Windows.Forms.DataGridView dataGridView56;
        private System.Windows.Forms.DataGridView dataGridView55;
        private System.Windows.Forms.DataGridView dataGridView54;
        private System.Windows.Forms.DataGridView dataGridView53;
        private System.Windows.Forms.DataGridView dataGridView52;
        private System.Windows.Forms.DataGridView dataGridView51;
        private System.Windows.Forms.DataGridView dataGridView50;
        private System.Windows.Forms.DataGridView dataGridView49;
        private System.Windows.Forms.DataGridView dataGridView48;
        private System.Windows.Forms.DataGridView dataGridView47;
        private System.Windows.Forms.DataGridView dataGridView46;
        private System.Windows.Forms.DataGridView dataGridView45;
        private System.Windows.Forms.DataGridView dataGridView44;
        private System.Windows.Forms.DataGridView dataGridView43;
        private System.Windows.Forms.DataGridView dataGridView42;
        private System.Windows.Forms.DataGridView dataGridView41;
        private System.Windows.Forms.DataGridView dataGridView40;
        private System.Windows.Forms.DataGridView dataGridView39;
        private System.Windows.Forms.DataGridView dataGridView38;
        private System.Windows.Forms.DataGridView dataGridView37;
        private System.Windows.Forms.DataGridView dataGridView36;
        private System.Windows.Forms.DataGridView dataGridView35;
        private System.Windows.Forms.DataGridView dataGridView34;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.DataGridView dataGridView33;
        private System.Windows.Forms.DataGridView dataGridView32;
        private System.Windows.Forms.DataGridView dataGridView31;
        private System.Windows.Forms.DataGridView dataGridView30;
        private System.Windows.Forms.DataGridView dataGridView29;
        private System.Windows.Forms.DataGridView dataGridView28;
        private System.Windows.Forms.DataGridView dataGridView27;
        private System.Windows.Forms.DataGridView dataGridView26;
        private System.Windows.Forms.DataGridView dataGridView25;
        private System.Windows.Forms.DataGridView dataGridView24;
        private System.Windows.Forms.DataGridView dataGridView23;
        private System.Windows.Forms.DataGridView dataGridView22;
        private System.Windows.Forms.DataGridView dataGridView21;
        private System.Windows.Forms.DataGridView dataGridView20;
        private System.Windows.Forms.DataGridView dataGridView19;
        private System.Windows.Forms.DataGridView dataGridView18;
        private System.Windows.Forms.DataGridView dataGridView17;
        private System.Windows.Forms.DataGridView dataGridView16;
        private System.Windows.Forms.DataGridView dataGridView15;
        private System.Windows.Forms.DataGridView dataGridView14;
        private System.Windows.Forms.DataGridView dataGridView13;
        private System.Windows.Forms.DataGridView dataGridView12;
        private System.Windows.Forms.DataGridView dataGridView11;
        private System.Windows.Forms.DataGridView dataGridView10;
        private System.Windows.Forms.DataGridView dataGridView9;
        private System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.MaskedTextBox maskedTextBox11;
        private System.Windows.Forms.MaskedTextBox maskedTextBox10;
        private System.Windows.Forms.MaskedTextBox maskedTextBox9;
        private System.Windows.Forms.MaskedTextBox maskedTextBox8;
        private System.Windows.Forms.MaskedTextBox maskedTextBox7;
        private System.Windows.Forms.MaskedTextBox maskedTextBox6;
        private System.Windows.Forms.MaskedTextBox maskedTextBox5;
        private System.Windows.Forms.MaskedTextBox maskedTextBox4;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.MaskedTextBox maskedTextBox3;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
    }
}