﻿namespace Nzanzu_MUTANGA_fRAnk
{
    partial class Consultation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label81 = new System.Windows.Forms.Label();
            this.Label82 = new System.Windows.Forms.Label();
            this.Label83 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.MaskedTextBox46 = new System.Windows.Forms.MaskedTextBox();
            this.CheckBox28 = new System.Windows.Forms.CheckBox();
            this.Label80 = new System.Windows.Forms.Label();
            this.Label79 = new System.Windows.Forms.Label();
            this.Label78 = new System.Windows.Forms.Label();
            this.MaskedTextBox45 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox44 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox43 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox42 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox41 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox40 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox39 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox38 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox37 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox36 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox35 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox34 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox33 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox32 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox31 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox30 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox29 = new System.Windows.Forms.MaskedTextBox();
            this.Label77 = new System.Windows.Forms.Label();
            this.Label76 = new System.Windows.Forms.Label();
            this.Label75 = new System.Windows.Forms.Label();
            this.Label74 = new System.Windows.Forms.Label();
            this.Label73 = new System.Windows.Forms.Label();
            this.Label72 = new System.Windows.Forms.Label();
            this.Label71 = new System.Windows.Forms.Label();
            this.Label70 = new System.Windows.Forms.Label();
            this.Label69 = new System.Windows.Forms.Label();
            this.Label68 = new System.Windows.Forms.Label();
            this.Label67 = new System.Windows.Forms.Label();
            this.Label66 = new System.Windows.Forms.Label();
            this.Label65 = new System.Windows.Forms.Label();
            this.Label64 = new System.Windows.Forms.Label();
            this.Label63 = new System.Windows.Forms.Label();
            this.Label62 = new System.Windows.Forms.Label();
            this.Label61 = new System.Windows.Forms.Label();
            this.Label60 = new System.Windows.Forms.Label();
            this.Label59 = new System.Windows.Forms.Label();
            this.Label58 = new System.Windows.Forms.Label();
            this.Label57 = new System.Windows.Forms.Label();
            this.CheckBox27 = new System.Windows.Forms.CheckBox();
            this.CheckBox26 = new System.Windows.Forms.CheckBox();
            this.CheckBox25 = new System.Windows.Forms.CheckBox();
            this.CheckBox24 = new System.Windows.Forms.CheckBox();
            this.CheckBox23 = new System.Windows.Forms.CheckBox();
            this.CheckBox22 = new System.Windows.Forms.CheckBox();
            this.CheckBox21 = new System.Windows.Forms.CheckBox();
            this.CheckBox20 = new System.Windows.Forms.CheckBox();
            this.CheckBox19 = new System.Windows.Forms.CheckBox();
            this.CheckBox18 = new System.Windows.Forms.CheckBox();
            this.CheckBox17 = new System.Windows.Forms.CheckBox();
            this.CheckBox16 = new System.Windows.Forms.CheckBox();
            this.CheckBox15 = new System.Windows.Forms.CheckBox();
            this.CheckBox14 = new System.Windows.Forms.CheckBox();
            this.CheckBox13 = new System.Windows.Forms.CheckBox();
            this.CheckBox12 = new System.Windows.Forms.CheckBox();
            this.CheckBox11 = new System.Windows.Forms.CheckBox();
            this.CheckBox10 = new System.Windows.Forms.CheckBox();
            this.CheckBox9 = new System.Windows.Forms.CheckBox();
            this.CheckBox8 = new System.Windows.Forms.CheckBox();
            this.CheckBox7 = new System.Windows.Forms.CheckBox();
            this.Label56 = new System.Windows.Forms.Label();
            this.Label55 = new System.Windows.Forms.Label();
            this.Label54 = new System.Windows.Forms.Label();
            this.Label53 = new System.Windows.Forms.Label();
            this.Label52 = new System.Windows.Forms.Label();
            this.Label51 = new System.Windows.Forms.Label();
            this.Label50 = new System.Windows.Forms.Label();
            this.Label49 = new System.Windows.Forms.Label();
            this.Label48 = new System.Windows.Forms.Label();
            this.Label47 = new System.Windows.Forms.Label();
            this.Label46 = new System.Windows.Forms.Label();
            this.Label45 = new System.Windows.Forms.Label();
            this.Label43 = new System.Windows.Forms.Label();
            this.Label42 = new System.Windows.Forms.Label();
            this.Label28 = new System.Windows.Forms.Label();
            this.DataGridView7 = new System.Windows.Forms.DataGridView();
            this.DataGridView6 = new System.Windows.Forms.DataGridView();
            this.DataGridView5 = new System.Windows.Forms.DataGridView();
            this.DataGridView4 = new System.Windows.Forms.DataGridView();
            this.DataGridView3 = new System.Windows.Forms.DataGridView();
            this.MaskedTextBox28 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox27 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox26 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox25 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox24 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox23 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox22 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox21 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox20 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox19 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox18 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox17 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox16 = new System.Windows.Forms.MaskedTextBox();
            this.Label44 = new System.Windows.Forms.Label();
            this.Label41 = new System.Windows.Forms.Label();
            this.Label40 = new System.Windows.Forms.Label();
            this.Label39 = new System.Windows.Forms.Label();
            this.Label38 = new System.Windows.Forms.Label();
            this.Label37 = new System.Windows.Forms.Label();
            this.Label36 = new System.Windows.Forms.Label();
            this.Label35 = new System.Windows.Forms.Label();
            this.Label34 = new System.Windows.Forms.Label();
            this.Label33 = new System.Windows.Forms.Label();
            this.Label32 = new System.Windows.Forms.Label();
            this.Label31 = new System.Windows.Forms.Label();
            this.Label30 = new System.Windows.Forms.Label();
            this.Label29 = new System.Windows.Forms.Label();
            this.Label27 = new System.Windows.Forms.Label();
            this.Label26 = new System.Windows.Forms.Label();
            this.DataGridView2 = new System.Windows.Forms.DataGridView();
            this.MaskedTextBox15 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox14 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox13 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox12 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox11 = new System.Windows.Forms.MaskedTextBox();
            this.Label25 = new System.Windows.Forms.Label();
            this.Label24 = new System.Windows.Forms.Label();
            this.Label23 = new System.Windows.Forms.Label();
            this.Label22 = new System.Windows.Forms.Label();
            this.Label21 = new System.Windows.Forms.Label();
            this.Label20 = new System.Windows.Forms.Label();
            this.Label19 = new System.Windows.Forms.Label();
            this.MaskedTextBox10 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox9 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox8 = new System.Windows.Forms.MaskedTextBox();
            this.CheckBox6 = new System.Windows.Forms.CheckBox();
            this.CheckBox5 = new System.Windows.Forms.CheckBox();
            this.CheckBox4 = new System.Windows.Forms.CheckBox();
            this.CheckBox3 = new System.Windows.Forms.CheckBox();
            this.Label18 = new System.Windows.Forms.Label();
            this.Label17 = new System.Windows.Forms.Label();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label15 = new System.Windows.Forms.Label();
            this.Label14 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.MaskedTextBox7 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox6 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox5 = new System.Windows.Forms.MaskedTextBox();
            this.CheckBox2 = new System.Windows.Forms.CheckBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label8 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.CheckBox1 = new System.Windows.Forms.CheckBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.MaskedTextBox4 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.panel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // Label81
            // 
            this.Label81.AutoSize = true;
            this.Label81.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label81.Location = new System.Drawing.Point(157, 17);
            this.Label81.Name = "Label81";
            this.Label81.Size = new System.Drawing.Size(119, 15);
            this.Label81.TabIndex = 725;
            this.Label81.Text = "Autres problèmes";
            // 
            // Label82
            // 
            this.Label82.AutoSize = true;
            this.Label82.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label82.Location = new System.Drawing.Point(368, 17);
            this.Label82.Name = "Label82";
            this.Label82.Size = new System.Drawing.Size(172, 15);
            this.Label82.TabIndex = 724;
            this.Label82.Text = "Traitement et Observation";
            // 
            // Label83
            // 
            this.Label83.AutoSize = true;
            this.Label83.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label83.Location = new System.Drawing.Point(27, 16);
            this.Label83.Name = "Label83";
            this.Label83.Size = new System.Drawing.Size(42, 15);
            this.Label83.TabIndex = 723;
            this.Label83.Text = "DATE";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Black;
            this.panel5.Location = new System.Drawing.Point(609, 12);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1, 685);
            this.panel5.TabIndex = 722;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.Black;
            this.panel20.Location = new System.Drawing.Point(10, 61);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(600, 1);
            this.panel20.TabIndex = 721;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.Black;
            this.panel16.Location = new System.Drawing.Point(10, 322);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(600, 1);
            this.panel16.TabIndex = 720;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.Black;
            this.panel15.Location = new System.Drawing.Point(10, 288);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(600, 1);
            this.panel15.TabIndex = 719;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.Black;
            this.panel14.Location = new System.Drawing.Point(10, 257);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(600, 1);
            this.panel14.TabIndex = 718;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Black;
            this.panel13.Location = new System.Drawing.Point(10, 226);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(600, 1);
            this.panel13.TabIndex = 717;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Black;
            this.panel12.Location = new System.Drawing.Point(10, 195);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(600, 1);
            this.panel12.TabIndex = 716;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Black;
            this.panel11.Location = new System.Drawing.Point(10, 169);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(600, 1);
            this.panel11.TabIndex = 715;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Black;
            this.panel10.Location = new System.Drawing.Point(10, 141);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(600, 1);
            this.panel10.TabIndex = 714;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(10, 115);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(600, 1);
            this.panel7.TabIndex = 713;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Black;
            this.panel6.Location = new System.Drawing.Point(10, 89);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(600, 1);
            this.panel6.TabIndex = 712;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(12, 35);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(598, 1);
            this.panel2.TabIndex = 711;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.Black;
            this.panel19.Location = new System.Drawing.Point(123, 14);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(1, 310);
            this.panel19.TabIndex = 710;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.Black;
            this.panel18.Controls.Add(this.panel4);
            this.panel18.Controls.Add(this.panel8);
            this.panel18.Location = new System.Drawing.Point(10, 12);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(1, 685);
            this.panel18.TabIndex = 709;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Black;
            this.panel4.Location = new System.Drawing.Point(0, 75);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(600, 1);
            this.panel4.TabIndex = 20;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(0, 132);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(600, 1);
            this.panel8.TabIndex = 24;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Black;
            this.panel17.Location = new System.Drawing.Point(326, 12);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(1, 310);
            this.panel17.TabIndex = 708;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(10, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(600, 1);
            this.panel1.TabIndex = 707;
            // 
            // MaskedTextBox46
            // 
            this.MaskedTextBox46.Location = new System.Drawing.Point(741, 700);
            this.MaskedTextBox46.Name = "MaskedTextBox46";
            this.MaskedTextBox46.Size = new System.Drawing.Size(414, 20);
            this.MaskedTextBox46.TabIndex = 706;
            this.MaskedTextBox46.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox46_MaskInputRejected);
            // 
            // CheckBox28
            // 
            this.CheckBox28.AutoSize = true;
            this.CheckBox28.Location = new System.Drawing.Point(1034, 679);
            this.CheckBox28.Name = "CheckBox28";
            this.CheckBox28.Size = new System.Drawing.Size(15, 14);
            this.CheckBox28.TabIndex = 705;
            this.CheckBox28.UseVisualStyleBackColor = true;
            this.CheckBox28.CheckedChanged += new System.EventHandler(this.CheckBox28_CheckedChanged);
            // 
            // Label80
            // 
            this.Label80.AutoSize = true;
            this.Label80.Location = new System.Drawing.Point(644, 700);
            this.Label80.Name = "Label80";
            this.Label80.Size = new System.Drawing.Size(91, 13);
            this.Label80.TabIndex = 704;
            this.Label80.Text = "Si oui, lesquelles :";
            this.Label80.Click += new System.EventHandler(this.Label80_Click);
            // 
            // Label79
            // 
            this.Label79.AutoSize = true;
            this.Label79.Location = new System.Drawing.Point(979, 679);
            this.Label79.Name = "Label79";
            this.Label79.Size = new System.Drawing.Size(26, 13);
            this.Label79.TabIndex = 703;
            this.Label79.Text = "OUI";
            this.Label79.Click += new System.EventHandler(this.Label79_Click);
            // 
            // Label78
            // 
            this.Label78.AutoSize = true;
            this.Label78.Location = new System.Drawing.Point(865, 680);
            this.Label78.Name = "Label78";
            this.Label78.Size = new System.Drawing.Size(31, 13);
            this.Label78.TabIndex = 702;
            this.Label78.Text = "NON";
            this.Label78.Click += new System.EventHandler(this.Label78_Click);
            // 
            // MaskedTextBox45
            // 
            this.MaskedTextBox45.Location = new System.Drawing.Point(742, 602);
            this.MaskedTextBox45.Name = "MaskedTextBox45";
            this.MaskedTextBox45.Size = new System.Drawing.Size(47, 20);
            this.MaskedTextBox45.TabIndex = 701;
            this.MaskedTextBox45.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox45_MaskInputRejected);
            // 
            // MaskedTextBox44
            // 
            this.MaskedTextBox44.Location = new System.Drawing.Point(1026, 602);
            this.MaskedTextBox44.Name = "MaskedTextBox44";
            this.MaskedTextBox44.Size = new System.Drawing.Size(77, 20);
            this.MaskedTextBox44.TabIndex = 700;
            this.MaskedTextBox44.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox44_MaskInputRejected);
            // 
            // MaskedTextBox43
            // 
            this.MaskedTextBox43.Location = new System.Drawing.Point(1303, 605);
            this.MaskedTextBox43.Name = "MaskedTextBox43";
            this.MaskedTextBox43.Size = new System.Drawing.Size(48, 20);
            this.MaskedTextBox43.TabIndex = 699;
            this.MaskedTextBox43.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox43_MaskInputRejected);
            // 
            // MaskedTextBox42
            // 
            this.MaskedTextBox42.Location = new System.Drawing.Point(1232, 621);
            this.MaskedTextBox42.Name = "MaskedTextBox42";
            this.MaskedTextBox42.Size = new System.Drawing.Size(53, 20);
            this.MaskedTextBox42.TabIndex = 698;
            this.MaskedTextBox42.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox42_MaskInputRejected);
            // 
            // MaskedTextBox41
            // 
            this.MaskedTextBox41.Location = new System.Drawing.Point(1232, 516);
            this.MaskedTextBox41.Name = "MaskedTextBox41";
            this.MaskedTextBox41.Size = new System.Drawing.Size(53, 20);
            this.MaskedTextBox41.TabIndex = 697;
            this.MaskedTextBox41.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox41_MaskInputRejected);
            // 
            // MaskedTextBox40
            // 
            this.MaskedTextBox40.Location = new System.Drawing.Point(1232, 572);
            this.MaskedTextBox40.Name = "MaskedTextBox40";
            this.MaskedTextBox40.Size = new System.Drawing.Size(53, 20);
            this.MaskedTextBox40.TabIndex = 696;
            this.MaskedTextBox40.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox40_MaskInputRejected);
            // 
            // MaskedTextBox39
            // 
            this.MaskedTextBox39.Location = new System.Drawing.Point(809, 541);
            this.MaskedTextBox39.Mask = "00/00/0000";
            this.MaskedTextBox39.Name = "MaskedTextBox39";
            this.MaskedTextBox39.Size = new System.Drawing.Size(81, 20);
            this.MaskedTextBox39.TabIndex = 695;
            this.MaskedTextBox39.ValidatingType = typeof(System.DateTime);
            this.MaskedTextBox39.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox39_MaskInputRejected);
            // 
            // MaskedTextBox38
            // 
            this.MaskedTextBox38.Location = new System.Drawing.Point(1301, 401);
            this.MaskedTextBox38.Name = "MaskedTextBox38";
            this.MaskedTextBox38.Size = new System.Drawing.Size(48, 20);
            this.MaskedTextBox38.TabIndex = 694;
            this.MaskedTextBox38.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox38_MaskInputRejected);
            // 
            // MaskedTextBox37
            // 
            this.MaskedTextBox37.Location = new System.Drawing.Point(1303, 461);
            this.MaskedTextBox37.Name = "MaskedTextBox37";
            this.MaskedTextBox37.Size = new System.Drawing.Size(48, 20);
            this.MaskedTextBox37.TabIndex = 693;
            this.MaskedTextBox37.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox37_MaskInputRejected);
            // 
            // MaskedTextBox36
            // 
            this.MaskedTextBox36.Location = new System.Drawing.Point(795, 499);
            this.MaskedTextBox36.Name = "MaskedTextBox36";
            this.MaskedTextBox36.Size = new System.Drawing.Size(67, 20);
            this.MaskedTextBox36.TabIndex = 692;
            this.MaskedTextBox36.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox36_MaskInputRejected);
            // 
            // MaskedTextBox35
            // 
            this.MaskedTextBox35.Location = new System.Drawing.Point(1232, 431);
            this.MaskedTextBox35.Name = "MaskedTextBox35";
            this.MaskedTextBox35.Size = new System.Drawing.Size(53, 20);
            this.MaskedTextBox35.TabIndex = 691;
            this.MaskedTextBox35.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox35_MaskInputRejected);
            // 
            // MaskedTextBox34
            // 
            this.MaskedTextBox34.Location = new System.Drawing.Point(1170, 434);
            this.MaskedTextBox34.Name = "MaskedTextBox34";
            this.MaskedTextBox34.Size = new System.Drawing.Size(46, 20);
            this.MaskedTextBox34.TabIndex = 690;
            this.MaskedTextBox34.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox34_MaskInputRejected);
            // 
            // MaskedTextBox33
            // 
            this.MaskedTextBox33.Location = new System.Drawing.Point(1303, 487);
            this.MaskedTextBox33.Name = "MaskedTextBox33";
            this.MaskedTextBox33.Size = new System.Drawing.Size(48, 20);
            this.MaskedTextBox33.TabIndex = 689;
            this.MaskedTextBox33.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox33_MaskInputRejected);
            // 
            // MaskedTextBox32
            // 
            this.MaskedTextBox32.Location = new System.Drawing.Point(1301, 349);
            this.MaskedTextBox32.Name = "MaskedTextBox32";
            this.MaskedTextBox32.Size = new System.Drawing.Size(48, 20);
            this.MaskedTextBox32.TabIndex = 688;
            this.MaskedTextBox32.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox32_MaskInputRejected);
            // 
            // MaskedTextBox31
            // 
            this.MaskedTextBox31.Location = new System.Drawing.Point(1232, 490);
            this.MaskedTextBox31.Name = "MaskedTextBox31";
            this.MaskedTextBox31.Size = new System.Drawing.Size(53, 20);
            this.MaskedTextBox31.TabIndex = 687;
            this.MaskedTextBox31.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox31_MaskInputRejected);
            // 
            // MaskedTextBox30
            // 
            this.MaskedTextBox30.Location = new System.Drawing.Point(1301, 375);
            this.MaskedTextBox30.Name = "MaskedTextBox30";
            this.MaskedTextBox30.Size = new System.Drawing.Size(48, 20);
            this.MaskedTextBox30.TabIndex = 686;
            this.MaskedTextBox30.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox30_MaskInputRejected);
            // 
            // MaskedTextBox29
            // 
            this.MaskedTextBox29.Location = new System.Drawing.Point(1174, 542);
            this.MaskedTextBox29.Name = "MaskedTextBox29";
            this.MaskedTextBox29.Size = new System.Drawing.Size(46, 20);
            this.MaskedTextBox29.TabIndex = 685;
            this.MaskedTextBox29.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBox29_MaskInputRejected);
            // 
            // Label77
            // 
            this.Label77.AutoSize = true;
            this.Label77.Location = new System.Drawing.Point(858, 641);
            this.Label77.Name = "Label77";
            this.Label77.Size = new System.Drawing.Size(91, 13);
            this.Label77.TabIndex = 684;
            this.Label77.Text = "mort avant 7 jours";
            this.Label77.Click += new System.EventHandler(this.Label77_Click);
            // 
            // Label76
            // 
            this.Label76.AutoSize = true;
            this.Label76.Location = new System.Drawing.Point(1038, 625);
            this.Label76.Name = "Label76";
            this.Label76.Size = new System.Drawing.Size(42, 13);
            this.Label76.TabIndex = 683;
            this.Label76.Text = "mort-né";
            this.Label76.Click += new System.EventHandler(this.Label76_Click);
            // 
            // Label75
            // 
            this.Label75.AutoSize = true;
            this.Label75.Location = new System.Drawing.Point(858, 624);
            this.Label75.Name = "Label75";
            this.Label75.Size = new System.Drawing.Size(63, 13);
            this.Label75.TabIndex = 682;
            this.Label75.Text = "pont-cinture";
            this.Label75.Click += new System.EventHandler(this.Label75_Click);
            // 
            // Label74
            // 
            this.Label74.AutoSize = true;
            this.Label74.Location = new System.Drawing.Point(662, 652);
            this.Label74.Name = "Label74";
            this.Label74.Size = new System.Drawing.Size(122, 13);
            this.Label74.TabIndex = 681;
            this.Label74.Text = "Traitement pour stérilité :";
            this.Label74.Click += new System.EventHandler(this.Label74_Click);
            // 
            // Label73
            // 
            this.Label73.AutoSize = true;
            this.Label73.Location = new System.Drawing.Point(662, 625);
            this.Label73.Name = "Label73";
            this.Label73.Size = new System.Drawing.Size(124, 13);
            this.Label73.TabIndex = 680;
            this.Label73.Text = "Dernier enfant prématuré";
            this.Label73.Click += new System.EventHandler(this.Label73_Click);
            // 
            // Label72
            // 
            this.Label72.AutoSize = true;
            this.Label72.Location = new System.Drawing.Point(795, 605);
            this.Label72.Name = "Label72";
            this.Label72.Size = new System.Drawing.Size(20, 13);
            this.Label72.TabIndex = 679;
            this.Label72.Text = "Kg";
            this.Label72.Click += new System.EventHandler(this.Label72_Click);
            // 
            // Label71
            // 
            this.Label71.AutoSize = true;
            this.Label71.Location = new System.Drawing.Point(954, 605);
            this.Label71.Name = "Label71";
            this.Label71.Size = new System.Drawing.Size(67, 13);
            this.Label71.TabIndex = 678;
            this.Label71.Text = "Plus de 4 Kg";
            this.Label71.Click += new System.EventHandler(this.Label71_Click);
            // 
            // Label70
            // 
            this.Label70.AutoSize = true;
            this.Label70.Location = new System.Drawing.Point(662, 605);
            this.Label70.Name = "Label70";
            this.Label70.Size = new System.Drawing.Size(78, 13);
            this.Label70.TabIndex = 677;
            this.Label70.Text = "Plus gros poids";
            this.Label70.Click += new System.EventHandler(this.Label70_Click);
            // 
            // Label69
            // 
            this.Label69.AutoSize = true;
            this.Label69.Location = new System.Drawing.Point(662, 681);
            this.Label69.Name = "Label69";
            this.Label69.Size = new System.Drawing.Size(132, 13);
            this.Label69.TabIndex = 676;
            this.Label69.Text = "Complication pont-paartum";
            this.Label69.Click += new System.EventHandler(this.Label69_Click);
            // 
            // Label68
            // 
            this.Label68.AutoSize = true;
            this.Label68.Location = new System.Drawing.Point(1014, 581);
            this.Label68.Name = "Label68";
            this.Label68.Size = new System.Drawing.Size(40, 13);
            this.Label68.TabIndex = 675;
            this.Label68.Text = "Eatocir";
            this.Label68.Click += new System.EventHandler(this.Label68_Click);
            // 
            // Label67
            // 
            this.Label67.AutoSize = true;
            this.Label67.Location = new System.Drawing.Point(1014, 562);
            this.Label67.Name = "Label67";
            this.Label67.Size = new System.Drawing.Size(46, 13);
            this.Label67.TabIndex = 674;
            this.Label67.Text = "Dyatocir";
            this.Label67.Click += new System.EventHandler(this.Label67_Click);
            // 
            // Label66
            // 
            this.Label66.AutoSize = true;
            this.Label66.Location = new System.Drawing.Point(1014, 545);
            this.Label66.Name = "Label66";
            this.Label66.Size = new System.Drawing.Size(61, 13);
            this.Label66.TabIndex = 673;
            this.Label66.Text = "Int < 2 mois";
            this.Label66.Click += new System.EventHandler(this.Label66_Click);
            // 
            // Label65
            // 
            this.Label65.AutoSize = true;
            this.Label65.Location = new System.Drawing.Point(662, 545);
            this.Label65.Name = "Label65";
            this.Label65.Size = new System.Drawing.Size(141, 13);
            this.Label65.TabIndex = 672;
            this.Label65.Text = "Dernier accouchement Date";
            this.Label65.Click += new System.EventHandler(this.Label65_Click);
            // 
            // Label64
            // 
            this.Label64.AutoSize = true;
            this.Label64.Location = new System.Drawing.Point(911, 523);
            this.Label64.Name = "Label64";
            this.Label64.Size = new System.Drawing.Size(77, 13);
            this.Label64.TabIndex = 671;
            this.Label64.Text = "30 Ans ou plus";
            this.Label64.Click += new System.EventHandler(this.Label64_Click);
            // 
            // Label63
            // 
            this.Label63.AutoSize = true;
            this.Label63.Location = new System.Drawing.Point(662, 524);
            this.Label63.Name = "Label63";
            this.Label63.Size = new System.Drawing.Size(146, 13);
            this.Label63.TabIndex = 670;
            this.Label63.Text = "Primipare de 15 Ans ou moins";
            this.Label63.Click += new System.EventHandler(this.Label63_Click);
            // 
            // Label62
            // 
            this.Label62.AutoSize = true;
            this.Label62.Location = new System.Drawing.Point(662, 502);
            this.Label62.Name = "Label62";
            this.Label62.Size = new System.Drawing.Size(127, 13);
            this.Label62.TabIndex = 669;
            this.Label62.Text = "Avortement du 1 trimestre";
            this.Label62.Click += new System.EventHandler(this.Label62_Click);
            // 
            // Label61
            // 
            this.Label61.AutoSize = true;
            this.Label61.Location = new System.Drawing.Point(1014, 478);
            this.Label61.Name = "Label61";
            this.Label61.Size = new System.Drawing.Size(66, 13);
            this.Label61.TabIndex = 668;
            this.Label61.Text = "Avortements";
            this.Label61.Click += new System.EventHandler(this.Label61_Click);
            // 
            // Label60
            // 
            this.Label60.AutoSize = true;
            this.Label60.Location = new System.Drawing.Point(876, 479);
            this.Label60.Name = "Label60";
            this.Label60.Size = new System.Drawing.Size(75, 13);
            this.Label60.TabIndex = 667;
            this.Label60.Text = "Enfants en vie";
            this.Label60.Click += new System.EventHandler(this.Label60_Click);
            // 
            // Label59
            // 
            this.Label59.AutoSize = true;
            this.Label59.Location = new System.Drawing.Point(756, 478);
            this.Label59.Name = "Label59";
            this.Label59.Size = new System.Drawing.Size(61, 13);
            this.Label59.TabIndex = 666;
            this.Label59.Text = "Grossesses";
            this.Label59.Click += new System.EventHandler(this.Label59_Click);
            // 
            // Label58
            // 
            this.Label58.AutoSize = true;
            this.Label58.Location = new System.Drawing.Point(662, 480);
            this.Label58.Name = "Label58";
            this.Label58.Size = new System.Drawing.Size(34, 13);
            this.Label58.TabIndex = 665;
            this.Label58.Text = "Parité";
            this.Label58.Click += new System.EventHandler(this.Label58_Click);
            // 
            // Label57
            // 
            this.Label57.AutoSize = true;
            this.Label57.Location = new System.Drawing.Point(662, 461);
            this.Label57.Name = "Label57";
            this.Label57.Size = new System.Drawing.Size(37, 13);
            this.Label57.TabIndex = 664;
            this.Label57.Text = "DDR :";
            this.Label57.Click += new System.EventHandler(this.Label57_Click);
            // 
            // CheckBox27
            // 
            this.CheckBox27.AutoSize = true;
            this.CheckBox27.Location = new System.Drawing.Point(788, 652);
            this.CheckBox27.Name = "CheckBox27";
            this.CheckBox27.Size = new System.Drawing.Size(15, 14);
            this.CheckBox27.TabIndex = 663;
            this.CheckBox27.UseVisualStyleBackColor = true;
            this.CheckBox27.CheckedChanged += new System.EventHandler(this.CheckBox27_CheckedChanged);
            // 
            // CheckBox26
            // 
            this.CheckBox26.AutoSize = true;
            this.CheckBox26.Location = new System.Drawing.Point(923, 679);
            this.CheckBox26.Name = "CheckBox26";
            this.CheckBox26.Size = new System.Drawing.Size(15, 14);
            this.CheckBox26.TabIndex = 662;
            this.CheckBox26.UseVisualStyleBackColor = true;
            this.CheckBox26.CheckedChanged += new System.EventHandler(this.CheckBox26_CheckedChanged);
            // 
            // CheckBox25
            // 
            this.CheckBox25.AutoSize = true;
            this.CheckBox25.Location = new System.Drawing.Point(1088, 578);
            this.CheckBox25.Name = "CheckBox25";
            this.CheckBox25.Size = new System.Drawing.Size(15, 14);
            this.CheckBox25.TabIndex = 661;
            this.CheckBox25.UseVisualStyleBackColor = true;
            this.CheckBox25.CheckedChanged += new System.EventHandler(this.CheckBox25_CheckedChanged);
            // 
            // CheckBox24
            // 
            this.CheckBox24.AutoSize = true;
            this.CheckBox24.Location = new System.Drawing.Point(1088, 624);
            this.CheckBox24.Name = "CheckBox24";
            this.CheckBox24.Size = new System.Drawing.Size(15, 14);
            this.CheckBox24.TabIndex = 660;
            this.CheckBox24.UseVisualStyleBackColor = true;
            this.CheckBox24.CheckedChanged += new System.EventHandler(this.CheckBox24_CheckedChanged);
            // 
            // CheckBox23
            // 
            this.CheckBox23.AutoSize = true;
            this.CheckBox23.Location = new System.Drawing.Point(923, 624);
            this.CheckBox23.Name = "CheckBox23";
            this.CheckBox23.Size = new System.Drawing.Size(15, 14);
            this.CheckBox23.TabIndex = 659;
            this.CheckBox23.UseVisualStyleBackColor = true;
            this.CheckBox23.CheckedChanged += new System.EventHandler(this.CheckBox23_CheckedChanged);
            // 
            // CheckBox22
            // 
            this.CheckBox22.AutoSize = true;
            this.CheckBox22.Location = new System.Drawing.Point(955, 641);
            this.CheckBox22.Name = "CheckBox22";
            this.CheckBox22.Size = new System.Drawing.Size(15, 14);
            this.CheckBox22.TabIndex = 658;
            this.CheckBox22.UseVisualStyleBackColor = true;
            this.CheckBox22.CheckedChanged += new System.EventHandler(this.CheckBox22_CheckedChanged);
            // 
            // CheckBox21
            // 
            this.CheckBox21.AutoSize = true;
            this.CheckBox21.Location = new System.Drawing.Point(791, 625);
            this.CheckBox21.Name = "CheckBox21";
            this.CheckBox21.Size = new System.Drawing.Size(15, 14);
            this.CheckBox21.TabIndex = 657;
            this.CheckBox21.UseVisualStyleBackColor = true;
            this.CheckBox21.CheckedChanged += new System.EventHandler(this.CheckBox21_CheckedChanged);
            // 
            // CheckBox20
            // 
            this.CheckBox20.AutoSize = true;
            this.CheckBox20.Location = new System.Drawing.Point(1088, 558);
            this.CheckBox20.Name = "CheckBox20";
            this.CheckBox20.Size = new System.Drawing.Size(15, 14);
            this.CheckBox20.TabIndex = 656;
            this.CheckBox20.UseVisualStyleBackColor = true;
            this.CheckBox20.CheckedChanged += new System.EventHandler(this.CheckBox20_CheckedChanged);
            // 
            // CheckBox19
            // 
            this.CheckBox19.AutoSize = true;
            this.CheckBox19.Location = new System.Drawing.Point(1088, 544);
            this.CheckBox19.Name = "CheckBox19";
            this.CheckBox19.Size = new System.Drawing.Size(15, 14);
            this.CheckBox19.TabIndex = 655;
            this.CheckBox19.UseVisualStyleBackColor = true;
            this.CheckBox19.CheckedChanged += new System.EventHandler(this.CheckBox19_CheckedChanged);
            // 
            // CheckBox18
            // 
            this.CheckBox18.AutoSize = true;
            this.CheckBox18.Location = new System.Drawing.Point(1006, 524);
            this.CheckBox18.Name = "CheckBox18";
            this.CheckBox18.Size = new System.Drawing.Size(15, 14);
            this.CheckBox18.TabIndex = 654;
            this.CheckBox18.UseVisualStyleBackColor = true;
            this.CheckBox18.CheckedChanged += new System.EventHandler(this.CheckBox18_CheckedChanged);
            // 
            // CheckBox17
            // 
            this.CheckBox17.AutoSize = true;
            this.CheckBox17.Location = new System.Drawing.Point(823, 478);
            this.CheckBox17.Name = "CheckBox17";
            this.CheckBox17.Size = new System.Drawing.Size(15, 14);
            this.CheckBox17.TabIndex = 653;
            this.CheckBox17.UseVisualStyleBackColor = true;
            this.CheckBox17.CheckedChanged += new System.EventHandler(this.CheckBox17_CheckedChanged);
            // 
            // CheckBox16
            // 
            this.CheckBox16.AutoSize = true;
            this.CheckBox16.Location = new System.Drawing.Point(959, 478);
            this.CheckBox16.Name = "CheckBox16";
            this.CheckBox16.Size = new System.Drawing.Size(15, 14);
            this.CheckBox16.TabIndex = 652;
            this.CheckBox16.UseVisualStyleBackColor = true;
            this.CheckBox16.CheckedChanged += new System.EventHandler(this.CheckBox16_CheckedChanged);
            // 
            // CheckBox15
            // 
            this.CheckBox15.AutoSize = true;
            this.CheckBox15.Location = new System.Drawing.Point(1099, 478);
            this.CheckBox15.Name = "CheckBox15";
            this.CheckBox15.Size = new System.Drawing.Size(15, 14);
            this.CheckBox15.TabIndex = 651;
            this.CheckBox15.UseVisualStyleBackColor = true;
            this.CheckBox15.CheckedChanged += new System.EventHandler(this.CheckBox15_CheckedChanged);
            // 
            // CheckBox14
            // 
            this.CheckBox14.AutoSize = true;
            this.CheckBox14.Location = new System.Drawing.Point(702, 478);
            this.CheckBox14.Name = "CheckBox14";
            this.CheckBox14.Size = new System.Drawing.Size(15, 14);
            this.CheckBox14.TabIndex = 650;
            this.CheckBox14.UseVisualStyleBackColor = true;
            this.CheckBox14.CheckedChanged += new System.EventHandler(this.CheckBox14_CheckedChanged);
            // 
            // CheckBox13
            // 
            this.CheckBox13.AutoSize = true;
            this.CheckBox13.Location = new System.Drawing.Point(812, 524);
            this.CheckBox13.Name = "CheckBox13";
            this.CheckBox13.Size = new System.Drawing.Size(15, 14);
            this.CheckBox13.TabIndex = 649;
            this.CheckBox13.UseVisualStyleBackColor = true;
            this.CheckBox13.CheckedChanged += new System.EventHandler(this.CheckBox13_CheckedChanged);
            // 
            // CheckBox12
            // 
            this.CheckBox12.AutoSize = true;
            this.CheckBox12.Location = new System.Drawing.Point(701, 420);
            this.CheckBox12.Name = "CheckBox12";
            this.CheckBox12.Size = new System.Drawing.Size(15, 14);
            this.CheckBox12.TabIndex = 648;
            this.CheckBox12.UseVisualStyleBackColor = true;
            this.CheckBox12.CheckedChanged += new System.EventHandler(this.CheckBox12_CheckedChanged);
            // 
            // CheckBox11
            // 
            this.CheckBox11.AutoSize = true;
            this.CheckBox11.Location = new System.Drawing.Point(1120, 395);
            this.CheckBox11.Name = "CheckBox11";
            this.CheckBox11.Size = new System.Drawing.Size(15, 14);
            this.CheckBox11.TabIndex = 647;
            this.CheckBox11.UseVisualStyleBackColor = true;
            this.CheckBox11.CheckedChanged += new System.EventHandler(this.CheckBox11_CheckedChanged);
            // 
            // CheckBox10
            // 
            this.CheckBox10.AutoSize = true;
            this.CheckBox10.Location = new System.Drawing.Point(990, 394);
            this.CheckBox10.Name = "CheckBox10";
            this.CheckBox10.Size = new System.Drawing.Size(15, 14);
            this.CheckBox10.TabIndex = 646;
            this.CheckBox10.UseVisualStyleBackColor = true;
            this.CheckBox10.CheckedChanged += new System.EventHandler(this.CheckBox10_CheckedChanged);
            // 
            // CheckBox9
            // 
            this.CheckBox9.AutoSize = true;
            this.CheckBox9.Location = new System.Drawing.Point(855, 394);
            this.CheckBox9.Name = "CheckBox9";
            this.CheckBox9.Size = new System.Drawing.Size(15, 14);
            this.CheckBox9.TabIndex = 645;
            this.CheckBox9.UseVisualStyleBackColor = true;
            this.CheckBox9.CheckedChanged += new System.EventHandler(this.CheckBox9_CheckedChanged);
            // 
            // CheckBox8
            // 
            this.CheckBox8.AutoSize = true;
            this.CheckBox8.Location = new System.Drawing.Point(759, 394);
            this.CheckBox8.Name = "CheckBox8";
            this.CheckBox8.Size = new System.Drawing.Size(15, 14);
            this.CheckBox8.TabIndex = 644;
            this.CheckBox8.UseVisualStyleBackColor = true;
            this.CheckBox8.CheckedChanged += new System.EventHandler(this.CheckBox8_CheckedChanged);
            // 
            // CheckBox7
            // 
            this.CheckBox7.AutoSize = true;
            this.CheckBox7.Location = new System.Drawing.Point(1065, 337);
            this.CheckBox7.Name = "CheckBox7";
            this.CheckBox7.Size = new System.Drawing.Size(81, 17);
            this.CheckBox7.TabIndex = 643;
            this.CheckBox7.Text = "CheckBox7";
            this.CheckBox7.UseVisualStyleBackColor = true;
            this.CheckBox7.CheckedChanged += new System.EventHandler(this.CheckBox7_CheckedChanged);
            // 
            // Label56
            // 
            this.Label56.AutoSize = true;
            this.Label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label56.Location = new System.Drawing.Point(662, 441);
            this.Label56.Name = "Label56";
            this.Label56.Size = new System.Drawing.Size(147, 13);
            this.Label56.TabIndex = 642;
            this.Label56.Text = "Antécédents obstericaux";
            this.Label56.Click += new System.EventHandler(this.Label56_Click);
            // 
            // Label55
            // 
            this.Label55.AutoSize = true;
            this.Label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label55.Location = new System.Drawing.Point(662, 420);
            this.Label55.Name = "Label55";
            this.Label55.Size = new System.Drawing.Size(33, 13);
            this.Label55.TabIndex = 641;
            this.Label55.Text = "GEU";
            this.Label55.Click += new System.EventHandler(this.Label55_Click);
            // 
            // Label54
            // 
            this.Label54.AutoSize = true;
            this.Label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label54.Location = new System.Drawing.Point(1023, 395);
            this.Label54.Name = "Label54";
            this.Label54.Size = new System.Drawing.Size(91, 13);
            this.Label54.TabIndex = 640;
            this.Label54.Text = "fracture bassin";
            this.Label54.Click += new System.EventHandler(this.Label54_Click);
            // 
            // Label53
            // 
            this.Label53.AutoSize = true;
            this.Label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label53.Location = new System.Drawing.Point(887, 394);
            this.Label53.Name = "Label53";
            this.Label53.Size = new System.Drawing.Size(87, 13);
            this.Label53.TabIndex = 639;
            this.Label53.Text = "fibreme interin";
            this.Label53.Click += new System.EventHandler(this.Label53_Click);
            // 
            // Label52
            // 
            this.Label52.AutoSize = true;
            this.Label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label52.Location = new System.Drawing.Point(788, 394);
            this.Label52.Name = "Label52";
            this.Label52.Size = new System.Drawing.Size(57, 13);
            this.Label52.TabIndex = 638;
            this.Label52.Text = "Cerclage";
            this.Label52.Click += new System.EventHandler(this.Label52_Click);
            // 
            // Label51
            // 
            this.Label51.AutoSize = true;
            this.Label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label51.Location = new System.Drawing.Point(683, 394);
            this.Label51.Name = "Label51";
            this.Label51.Size = new System.Drawing.Size(70, 13);
            this.Label51.TabIndex = 637;
            this.Label51.Text = "Césarienne";
            this.Label51.Click += new System.EventHandler(this.Label51_Click);
            // 
            // Label50
            // 
            this.Label50.AutoSize = true;
            this.Label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label50.Location = new System.Drawing.Point(665, 373);
            this.Label50.Name = "Label50";
            this.Label50.Size = new System.Drawing.Size(141, 13);
            this.Label50.TabIndex = 636;
            this.Label50.Text = "Antécedents Chirgicaux";
            this.Label50.Click += new System.EventHandler(this.Label50_Click);
            // 
            // Label49
            // 
            this.Label49.AutoSize = true;
            this.Label49.Location = new System.Drawing.Point(938, 336);
            this.Label49.Name = "Label49";
            this.Label49.Size = new System.Drawing.Size(84, 13);
            this.Label49.TabIndex = 635;
            this.Label49.Text = "TEST-VIH-SIDA";
            this.Label49.Click += new System.EventHandler(this.Label49_Click);
            // 
            // Label48
            // 
            this.Label48.AutoSize = true;
            this.Label48.Location = new System.Drawing.Point(911, 316);
            this.Label48.Name = "Label48";
            this.Label48.Size = new System.Drawing.Size(169, 13);
            this.Label48.TabIndex = 634;
            this.Label48.Text = "TB-HTA-SCA-AR-PEMO-MCIP-RA";
            this.Label48.Click += new System.EventHandler(this.Label48_Click);
            // 
            // Label47
            // 
            this.Label47.AutoSize = true;
            this.Label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label47.Location = new System.Drawing.Point(664, 316);
            this.Label47.Name = "Label47";
            this.Label47.Size = new System.Drawing.Size(143, 13);
            this.Label47.TabIndex = 633;
            this.Label47.Text = "Antecendents Médicaux";
            this.Label47.Click += new System.EventHandler(this.Label47_Click);
            // 
            // Label46
            // 
            this.Label46.AutoSize = true;
            this.Label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label46.Location = new System.Drawing.Point(749, 286);
            this.Label46.Name = "Label46";
            this.Label46.Size = new System.Drawing.Size(293, 15);
            this.Label46.TabIndex = 632;
            this.Label46.Text = "ENTECEDENT & RENSEIGNEMENT GENERAL";
            this.Label46.Click += new System.EventHandler(this.Label46_Click);
            // 
            // Label45
            // 
            this.Label45.AutoSize = true;
            this.Label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label45.Location = new System.Drawing.Point(1303, 320);
            this.Label45.Name = "Label45";
            this.Label45.Size = new System.Drawing.Size(46, 15);
            this.Label45.TabIndex = 631;
            this.Label45.Text = "NAT P";
            this.Label45.Click += new System.EventHandler(this.Label45_Click);
            // 
            // Label43
            // 
            this.Label43.AutoSize = true;
            this.Label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label43.Location = new System.Drawing.Point(1223, 320);
            this.Label43.Name = "Label43";
            this.Label43.Size = new System.Drawing.Size(63, 13);
            this.Label43.TabIndex = 630;
            this.Label43.Text = "MERCRIC";
            this.Label43.Click += new System.EventHandler(this.Label43_Click);
            // 
            // Label42
            // 
            this.Label42.AutoSize = true;
            this.Label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label42.Location = new System.Drawing.Point(1176, 320);
            this.Label42.Name = "Label42";
            this.Label42.Size = new System.Drawing.Size(25, 15);
            this.Label42.TabIndex = 629;
            this.Label42.Text = "CB";
            this.Label42.Click += new System.EventHandler(this.Label42_Click);
            // 
            // Label28
            // 
            this.Label28.AutoSize = true;
            this.Label28.Font = new System.Drawing.Font("Arial Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label28.Location = new System.Drawing.Point(1230, 286);
            this.Label28.Name = "Label28";
            this.Label28.Size = new System.Drawing.Size(74, 17);
            this.Label28.TabIndex = 628;
            this.Label28.Text = "Brand-php";
            this.Label28.Click += new System.EventHandler(this.Label28_Click);
            // 
            // DataGridView7
            // 
            this.DataGridView7.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView7.Location = new System.Drawing.Point(1292, 309);
            this.DataGridView7.Name = "DataGridView7";
            this.DataGridView7.Size = new System.Drawing.Size(68, 435);
            this.DataGridView7.TabIndex = 627;
            this.DataGridView7.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView7_CellContentClick);
            // 
            // DataGridView6
            // 
            this.DataGridView6.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView6.Location = new System.Drawing.Point(1222, 309);
            this.DataGridView6.Name = "DataGridView6";
            this.DataGridView6.Size = new System.Drawing.Size(75, 435);
            this.DataGridView6.TabIndex = 626;
            this.DataGridView6.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView6_CellContentClick);
            // 
            // DataGridView5
            // 
            this.DataGridView5.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView5.Location = new System.Drawing.Point(1168, 309);
            this.DataGridView5.Name = "DataGridView5";
            this.DataGridView5.Size = new System.Drawing.Size(58, 435);
            this.DataGridView5.TabIndex = 625;
            this.DataGridView5.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView5_CellContentClick);
            // 
            // DataGridView4
            // 
            this.DataGridView4.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView4.Location = new System.Drawing.Point(1168, 281);
            this.DataGridView4.Name = "DataGridView4";
            this.DataGridView4.Size = new System.Drawing.Size(192, 28);
            this.DataGridView4.TabIndex = 624;
            this.DataGridView4.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView4_CellContentClick);
            // 
            // DataGridView3
            // 
            this.DataGridView3.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView3.Location = new System.Drawing.Point(643, 281);
            this.DataGridView3.Name = "DataGridView3";
            this.DataGridView3.Size = new System.Drawing.Size(527, 463);
            this.DataGridView3.TabIndex = 623;
            this.DataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView3_CellContentClick);
            // 
            // MaskedTextBox28
            // 
            this.MaskedTextBox28.Location = new System.Drawing.Point(717, 255);
            this.MaskedTextBox28.Name = "MaskedTextBox28";
            this.MaskedTextBox28.Size = new System.Drawing.Size(304, 20);
            this.MaskedTextBox28.TabIndex = 622;
            // 
            // MaskedTextBox27
            // 
            this.MaskedTextBox27.Location = new System.Drawing.Point(1124, 186);
            this.MaskedTextBox27.Name = "MaskedTextBox27";
            this.MaskedTextBox27.Size = new System.Drawing.Size(207, 20);
            this.MaskedTextBox27.TabIndex = 621;
            // 
            // MaskedTextBox26
            // 
            this.MaskedTextBox26.Location = new System.Drawing.Point(1110, 163);
            this.MaskedTextBox26.Name = "MaskedTextBox26";
            this.MaskedTextBox26.Size = new System.Drawing.Size(221, 20);
            this.MaskedTextBox26.TabIndex = 620;
            // 
            // MaskedTextBox25
            // 
            this.MaskedTextBox25.Location = new System.Drawing.Point(713, 232);
            this.MaskedTextBox25.Name = "MaskedTextBox25";
            this.MaskedTextBox25.Size = new System.Drawing.Size(309, 20);
            this.MaskedTextBox25.TabIndex = 619;
            // 
            // MaskedTextBox24
            // 
            this.MaskedTextBox24.Location = new System.Drawing.Point(742, 207);
            this.MaskedTextBox24.Name = "MaskedTextBox24";
            this.MaskedTextBox24.Size = new System.Drawing.Size(280, 20);
            this.MaskedTextBox24.TabIndex = 618;
            // 
            // MaskedTextBox23
            // 
            this.MaskedTextBox23.Location = new System.Drawing.Point(791, 186);
            this.MaskedTextBox23.Name = "MaskedTextBox23";
            this.MaskedTextBox23.Size = new System.Drawing.Size(230, 20);
            this.MaskedTextBox23.TabIndex = 617;
            // 
            // MaskedTextBox22
            // 
            this.MaskedTextBox22.Location = new System.Drawing.Point(812, 163);
            this.MaskedTextBox22.Name = "MaskedTextBox22";
            this.MaskedTextBox22.Size = new System.Drawing.Size(209, 20);
            this.MaskedTextBox22.TabIndex = 616;
            // 
            // MaskedTextBox21
            // 
            this.MaskedTextBox21.Location = new System.Drawing.Point(1240, 67);
            this.MaskedTextBox21.Name = "MaskedTextBox21";
            this.MaskedTextBox21.Size = new System.Drawing.Size(91, 20);
            this.MaskedTextBox21.TabIndex = 615;
            // 
            // MaskedTextBox20
            // 
            this.MaskedTextBox20.Location = new System.Drawing.Point(1224, 45);
            this.MaskedTextBox20.Name = "MaskedTextBox20";
            this.MaskedTextBox20.Size = new System.Drawing.Size(107, 20);
            this.MaskedTextBox20.TabIndex = 614;
            // 
            // MaskedTextBox19
            // 
            this.MaskedTextBox19.Location = new System.Drawing.Point(843, 112);
            this.MaskedTextBox19.Name = "MaskedTextBox19";
            this.MaskedTextBox19.Size = new System.Drawing.Size(261, 20);
            this.MaskedTextBox19.TabIndex = 613;
            // 
            // MaskedTextBox18
            // 
            this.MaskedTextBox18.Location = new System.Drawing.Point(773, 89);
            this.MaskedTextBox18.Name = "MaskedTextBox18";
            this.MaskedTextBox18.Size = new System.Drawing.Size(330, 20);
            this.MaskedTextBox18.TabIndex = 612;
            // 
            // MaskedTextBox17
            // 
            this.MaskedTextBox17.Location = new System.Drawing.Point(743, 67);
            this.MaskedTextBox17.Name = "MaskedTextBox17";
            this.MaskedTextBox17.Size = new System.Drawing.Size(361, 20);
            this.MaskedTextBox17.TabIndex = 611;
            // 
            // MaskedTextBox16
            // 
            this.MaskedTextBox16.Location = new System.Drawing.Point(743, 45);
            this.MaskedTextBox16.Name = "MaskedTextBox16";
            this.MaskedTextBox16.Size = new System.Drawing.Size(361, 20);
            this.MaskedTextBox16.TabIndex = 610;
            // 
            // Label44
            // 
            this.Label44.AutoSize = true;
            this.Label44.Font = new System.Drawing.Font("Arial Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label44.Location = new System.Drawing.Point(865, 143);
            this.Label44.Name = "Label44";
            this.Label44.Size = new System.Drawing.Size(239, 17);
            this.Label44.TabIndex = 609;
            this.Label44.Text = "CONSULTATION PRENETALE (CPN)";
            // 
            // Label41
            // 
            this.Label41.AutoSize = true;
            this.Label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label41.Location = new System.Drawing.Point(662, 171);
            this.Label41.Name = "Label41";
            this.Label41.Size = new System.Drawing.Size(144, 13);
            this.Label41.TabIndex = 608;
            this.Label41.Text = "NOMS ET POSTNOMS :";
            // 
            // Label40
            // 
            this.Label40.AutoSize = true;
            this.Label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label40.Location = new System.Drawing.Point(662, 193);
            this.Label40.Name = "Label40";
            this.Label40.Size = new System.Drawing.Size(121, 13);
            this.Label40.TabIndex = 607;
            this.Label40.Text = "Date de naissance :";
            // 
            // Label39
            // 
            this.Label39.AutoSize = true;
            this.Label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label39.Location = new System.Drawing.Point(662, 210);
            this.Label39.Name = "Label39";
            this.Label39.Size = new System.Drawing.Size(73, 13);
            this.Label39.TabIndex = 606;
            this.Label39.Text = "Partenaire :";
            // 
            // Label38
            // 
            this.Label38.AutoSize = true;
            this.Label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label38.Location = new System.Drawing.Point(662, 232);
            this.Label38.Name = "Label38";
            this.Label38.Size = new System.Drawing.Size(60, 13);
            this.Label38.TabIndex = 605;
            this.Label38.Text = "Adresse :";
            // 
            // Label37
            // 
            this.Label37.AutoSize = true;
            this.Label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label37.Location = new System.Drawing.Point(1197, 48);
            this.Label37.Name = "Label37";
            this.Label37.Size = new System.Drawing.Size(29, 13);
            this.Label37.TabIndex = 604;
            this.Label37.Text = "N° :";
            // 
            // Label36
            // 
            this.Label36.AutoSize = true;
            this.Label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label36.Location = new System.Drawing.Point(662, 115);
            this.Label36.Name = "Label36";
            this.Label36.Size = new System.Drawing.Size(180, 13);
            this.Label36.TabIndex = 603;
            this.Label36.Text = "A.S /FORMATION BANITAIRE";
            // 
            // Label35
            // 
            this.Label35.AutoSize = true;
            this.Label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label35.Location = new System.Drawing.Point(662, 48);
            this.Label35.Name = "Label35";
            this.Label35.Size = new System.Drawing.Size(70, 13);
            this.Label35.TabIndex = 602;
            this.Label35.Text = "PROVINCE";
            // 
            // Label34
            // 
            this.Label34.AutoSize = true;
            this.Label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label34.Location = new System.Drawing.Point(662, 255);
            this.Label34.Name = "Label34";
            this.Label34.Size = new System.Drawing.Size(47, 13);
            this.Label34.TabIndex = 601;
            this.Label34.Text = "Plaire :";
            // 
            // Label33
            // 
            this.Label33.AutoSize = true;
            this.Label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label33.Location = new System.Drawing.Point(1038, 184);
            this.Label33.Name = "Label33";
            this.Label33.Size = new System.Drawing.Size(80, 13);
            this.Label33.TabIndex = 600;
            this.Label33.Text = "Occupation :";
            // 
            // Label32
            // 
            this.Label32.AutoSize = true;
            this.Label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label32.Location = new System.Drawing.Point(662, 28);
            this.Label32.Name = "Label32";
            this.Label32.Size = new System.Drawing.Size(208, 13);
            this.Label32.TabIndex = 599;
            this.Label32.Text = "MINISTERE DE LA SANTE / PNSR";
            // 
            // Label31
            // 
            this.Label31.AutoSize = true;
            this.Label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label31.Location = new System.Drawing.Point(1197, 70);
            this.Label31.Name = "Label31";
            this.Label31.Size = new System.Drawing.Size(42, 13);
            this.Label31.TabIndex = 598;
            this.Label31.Text = "Date :";
            // 
            // Label30
            // 
            this.Label30.AutoSize = true;
            this.Label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label30.Location = new System.Drawing.Point(662, 92);
            this.Label30.Name = "Label30";
            this.Label30.Size = new System.Drawing.Size(107, 13);
            this.Label30.TabIndex = 597;
            this.Label30.Text = "ZONE DE SANTE";
            // 
            // Label29
            // 
            this.Label29.AutoSize = true;
            this.Label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label29.Location = new System.Drawing.Point(1038, 171);
            this.Label29.Name = "Label29";
            this.Label29.Size = new System.Drawing.Size(66, 13);
            this.Label29.TabIndex = 596;
            this.Label29.Text = "Etat Civil :";
            // 
            // Label27
            // 
            this.Label27.AutoSize = true;
            this.Label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label27.Location = new System.Drawing.Point(662, 70);
            this.Label27.Name = "Label27";
            this.Label27.Size = new System.Drawing.Size(65, 13);
            this.Label27.TabIndex = 595;
            this.Label27.Text = "DISTRICT";
            // 
            // Label26
            // 
            this.Label26.AutoSize = true;
            this.Label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label26.Location = new System.Drawing.Point(662, 12);
            this.Label26.Name = "Label26";
            this.Label26.Size = new System.Drawing.Size(259, 13);
            this.Label26.TabIndex = 594;
            this.Label26.Text = "REPUBLIQUE DEMOCRATIQUE DU CONGO";
            // 
            // DataGridView2
            // 
            this.DataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView2.Location = new System.Drawing.Point(643, 5);
            this.DataGridView2.Name = "DataGridView2";
            this.DataGridView2.Size = new System.Drawing.Size(717, 712);
            this.DataGridView2.TabIndex = 593;
            this.DataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView2_CellContentClick);
            // 
            // MaskedTextBox15
            // 
            this.MaskedTextBox15.Location = new System.Drawing.Point(502, 632);
            this.MaskedTextBox15.Name = "MaskedTextBox15";
            this.MaskedTextBox15.Size = new System.Drawing.Size(56, 20);
            this.MaskedTextBox15.TabIndex = 592;
            // 
            // MaskedTextBox14
            // 
            this.MaskedTextBox14.Location = new System.Drawing.Point(312, 632);
            this.MaskedTextBox14.Name = "MaskedTextBox14";
            this.MaskedTextBox14.Size = new System.Drawing.Size(56, 20);
            this.MaskedTextBox14.TabIndex = 591;
            // 
            // MaskedTextBox13
            // 
            this.MaskedTextBox13.Location = new System.Drawing.Point(101, 632);
            this.MaskedTextBox13.Name = "MaskedTextBox13";
            this.MaskedTextBox13.Size = new System.Drawing.Size(91, 20);
            this.MaskedTextBox13.TabIndex = 590;
            // 
            // MaskedTextBox12
            // 
            this.MaskedTextBox12.Location = new System.Drawing.Point(144, 610);
            this.MaskedTextBox12.Name = "MaskedTextBox12";
            this.MaskedTextBox12.Size = new System.Drawing.Size(56, 20);
            this.MaskedTextBox12.TabIndex = 589;
            // 
            // MaskedTextBox11
            // 
            this.MaskedTextBox11.Location = new System.Drawing.Point(144, 588);
            this.MaskedTextBox11.Name = "MaskedTextBox11";
            this.MaskedTextBox11.Size = new System.Drawing.Size(56, 20);
            this.MaskedTextBox11.TabIndex = 588;
            // 
            // Label25
            // 
            this.Label25.AutoSize = true;
            this.Label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label25.Location = new System.Drawing.Point(138, 693);
            this.Label25.Name = "Label25";
            this.Label25.Size = new System.Drawing.Size(264, 13);
            this.Label25.TabIndex = 587;
            this.Label25.Text = "EVOLUTION DE LA GROSSESSE ACTUELLE";
            // 
            // Label24
            // 
            this.Label24.AutoSize = true;
            this.Label24.Font = new System.Drawing.Font("Goudy Old Style", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label24.Location = new System.Drawing.Point(165, 653);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(234, 14);
            this.Label24.TabIndex = 586;
            this.Label24.Text = "Apporter cette fiche à la CPN de votre prochaine grossesse";
            // 
            // Label23
            // 
            this.Label23.AutoSize = true;
            this.Label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label23.Location = new System.Drawing.Point(445, 635);
            this.Label23.Name = "Label23";
            this.Label23.Size = new System.Drawing.Size(51, 13);
            this.Label23.TabIndex = 585;
            this.Label23.Text = "C.P.S. :";
            // 
            // Label22
            // 
            this.Label22.AutoSize = true;
            this.Label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label22.Location = new System.Drawing.Point(280, 635);
            this.Label22.Name = "Label22";
            this.Label22.Size = new System.Drawing.Size(26, 13);
            this.Label22.TabIndex = 584;
            this.Label22.Text = "P.F";
            // 
            // Label21
            // 
            this.Label21.AutoSize = true;
            this.Label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label21.Location = new System.Drawing.Point(12, 635);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(76, 13);
            this.Label21.TabIndex = 583;
            this.Label21.Text = "R.V. : CPoN";
            // 
            // Label20
            // 
            this.Label20.AutoSize = true;
            this.Label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label20.Location = new System.Drawing.Point(12, 613);
            this.Label20.Name = "Label20";
            this.Label20.Size = new System.Drawing.Size(81, 13);
            this.Label20.TabIndex = 582;
            this.Label20.Text = "Fer à la mère";
            // 
            // Label19
            // 
            this.Label19.AutoSize = true;
            this.Label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label19.Location = new System.Drawing.Point(12, 591);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(79, 13);
            this.Label19.TabIndex = 581;
            this.Label19.Text = "Vit A la mère";
            // 
            // MaskedTextBox10
            // 
            this.MaskedTextBox10.Location = new System.Drawing.Point(172, 546);
            this.MaskedTextBox10.Name = "MaskedTextBox10";
            this.MaskedTextBox10.Size = new System.Drawing.Size(368, 20);
            this.MaskedTextBox10.TabIndex = 580;
            // 
            // MaskedTextBox9
            // 
            this.MaskedTextBox9.Location = new System.Drawing.Point(172, 521);
            this.MaskedTextBox9.Name = "MaskedTextBox9";
            this.MaskedTextBox9.Size = new System.Drawing.Size(368, 20);
            this.MaskedTextBox9.TabIndex = 579;
            // 
            // MaskedTextBox8
            // 
            this.MaskedTextBox8.Location = new System.Drawing.Point(216, 495);
            this.MaskedTextBox8.Name = "MaskedTextBox8";
            this.MaskedTextBox8.Size = new System.Drawing.Size(324, 20);
            this.MaskedTextBox8.TabIndex = 578;
            // 
            // CheckBox6
            // 
            this.CheckBox6.AutoSize = true;
            this.CheckBox6.Location = new System.Drawing.Point(595, 480);
            this.CheckBox6.Name = "CheckBox6";
            this.CheckBox6.Size = new System.Drawing.Size(15, 14);
            this.CheckBox6.TabIndex = 577;
            this.CheckBox6.UseVisualStyleBackColor = true;
            // 
            // CheckBox5
            // 
            this.CheckBox5.AutoSize = true;
            this.CheckBox5.Location = new System.Drawing.Point(448, 480);
            this.CheckBox5.Name = "CheckBox5";
            this.CheckBox5.Size = new System.Drawing.Size(15, 14);
            this.CheckBox5.TabIndex = 576;
            this.CheckBox5.UseVisualStyleBackColor = true;
            // 
            // CheckBox4
            // 
            this.CheckBox4.AutoSize = true;
            this.CheckBox4.Location = new System.Drawing.Point(189, 479);
            this.CheckBox4.Name = "CheckBox4";
            this.CheckBox4.Size = new System.Drawing.Size(15, 14);
            this.CheckBox4.TabIndex = 575;
            this.CheckBox4.UseVisualStyleBackColor = true;
            // 
            // CheckBox3
            // 
            this.CheckBox3.AutoSize = true;
            this.CheckBox3.Location = new System.Drawing.Point(74, 479);
            this.CheckBox3.Name = "CheckBox3";
            this.CheckBox3.Size = new System.Drawing.Size(15, 14);
            this.CheckBox3.TabIndex = 574;
            this.CheckBox3.UseVisualStyleBackColor = true;
            // 
            // Label18
            // 
            this.Label18.AutoSize = true;
            this.Label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label18.Location = new System.Drawing.Point(12, 444);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(40, 13);
            this.Label18.TabIndex = 573;
            this.Label18.Text = "B.C.G";
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label17.Location = new System.Drawing.Point(113, 480);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(46, 13);
            this.Label17.TabIndex = 572;
            this.Label17.Text = "Polio 1";
            // 
            // Label16
            // 
            this.Label16.AutoSize = true;
            this.Label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label16.Location = new System.Drawing.Point(233, 480);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(192, 13);
            this.Label16.TabIndex = 571;
            this.Label16.Text = "Névirapine enfant si maman PVV";
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label15.Location = new System.Drawing.Point(491, 480);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(101, 13);
            this.Label15.TabIndex = 570;
            this.Label15.Text = "Mort avant 24h :";
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label14.Location = new System.Drawing.Point(12, 502);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(198, 13);
            this.Label14.TabIndex = 569;
            this.Label14.Text = "Complication de l\'accouchement :";
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label13.Location = new System.Drawing.Point(12, 524);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(149, 13);
            this.Label13.TabIndex = 568;
            this.Label13.Text = "Réanimation de l\'enfant :";
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.Location = new System.Drawing.Point(12, 546);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(158, 13);
            this.Label12.TabIndex = 567;
            this.Label12.Text = "Complication pont-partum :";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.Location = new System.Drawing.Point(12, 569);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(383, 13);
            this.Label11.TabIndex = 566;
            this.Label11.Text = "Allaitement maternel exclusif dans l\'heure qui suit l\'accouchement ";
            // 
            // MaskedTextBox7
            // 
            this.MaskedTextBox7.Location = new System.Drawing.Point(74, 453);
            this.MaskedTextBox7.Name = "MaskedTextBox7";
            this.MaskedTextBox7.Size = new System.Drawing.Size(118, 20);
            this.MaskedTextBox7.TabIndex = 565;
            // 
            // MaskedTextBox6
            // 
            this.MaskedTextBox6.Location = new System.Drawing.Point(472, 453);
            this.MaskedTextBox6.Name = "MaskedTextBox6";
            this.MaskedTextBox6.Size = new System.Drawing.Size(56, 20);
            this.MaskedTextBox6.TabIndex = 564;
            // 
            // MaskedTextBox5
            // 
            this.MaskedTextBox5.Location = new System.Drawing.Point(342, 454);
            this.MaskedTextBox5.Name = "MaskedTextBox5";
            this.MaskedTextBox5.Size = new System.Drawing.Size(56, 20);
            this.MaskedTextBox5.TabIndex = 563;
            // 
            // CheckBox2
            // 
            this.CheckBox2.AutoSize = true;
            this.CheckBox2.Location = new System.Drawing.Point(594, 457);
            this.CheckBox2.Name = "CheckBox2";
            this.CheckBox2.Size = new System.Drawing.Size(15, 14);
            this.CheckBox2.TabIndex = 562;
            this.CheckBox2.UseVisualStyleBackColor = true;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.Location = new System.Drawing.Point(534, 456);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(58, 13);
            this.Label10.TabIndex = 561;
            this.Label10.Text = "Mort-né :";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label9.Location = new System.Drawing.Point(420, 456);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(43, 13);
            this.Label9.TabIndex = 560;
            this.Label9.Text = "Sexe :";
            // 
            // Label8
            // 
            this.Label8.AutoSize = true;
            this.Label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label8.Location = new System.Drawing.Point(280, 456);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(46, 13);
            this.Label8.TabIndex = 559;
            this.Label8.Text = "Poids :";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label7.Location = new System.Drawing.Point(12, 457);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(52, 13);
            this.Label7.TabIndex = 558;
            this.Label7.Text = "Enfant :";
            // 
            // CheckBox1
            // 
            this.CheckBox1.AutoSize = true;
            this.CheckBox1.Location = new System.Drawing.Point(484, 433);
            this.CheckBox1.Name = "CheckBox1";
            this.CheckBox1.Size = new System.Drawing.Size(15, 14);
            this.CheckBox1.TabIndex = 557;
            this.CheckBox1.UseVisualStyleBackColor = true;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(312, 433);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(166, 13);
            this.Label6.TabIndex = 556;
            this.Label6.Text = "Névirapine co si mère PVV :";
            // 
            // MaskedTextBox4
            // 
            this.MaskedTextBox4.Location = new System.Drawing.Point(60, 410);
            this.MaskedTextBox4.Mask = "00/00/0000";
            this.MaskedTextBox4.Name = "MaskedTextBox4";
            this.MaskedTextBox4.Size = new System.Drawing.Size(56, 20);
            this.MaskedTextBox4.TabIndex = 555;
            this.MaskedTextBox4.ValidatingType = typeof(System.DateTime);
            // 
            // MaskedTextBox3
            // 
            this.MaskedTextBox3.Location = new System.Drawing.Point(523, 410);
            this.MaskedTextBox3.Name = "MaskedTextBox3";
            this.MaskedTextBox3.Size = new System.Drawing.Size(56, 20);
            this.MaskedTextBox3.TabIndex = 554;
            // 
            // MaskedTextBox2
            // 
            this.MaskedTextBox2.Location = new System.Drawing.Point(364, 410);
            this.MaskedTextBox2.Name = "MaskedTextBox2";
            this.MaskedTextBox2.Size = new System.Drawing.Size(56, 20);
            this.MaskedTextBox2.TabIndex = 553;
            // 
            // MaskedTextBox1
            // 
            this.MaskedTextBox1.Location = new System.Drawing.Point(204, 410);
            this.MaskedTextBox1.Name = "MaskedTextBox1";
            this.MaskedTextBox1.Size = new System.Drawing.Size(56, 20);
            this.MaskedTextBox1.TabIndex = 552;
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label5.Location = new System.Drawing.Point(469, 413);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(48, 13);
            this.Label5.TabIndex = 551;
            this.Label5.Text = "Apgar :";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label4.Location = new System.Drawing.Point(312, 413);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(46, 13);
            this.Label4.TabIndex = 550;
            this.Label4.Text = "Mode :";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(165, 413);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(39, 13);
            this.Label3.TabIndex = 549;
            this.Label3.Text = "Lieu :";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label2.Location = new System.Drawing.Point(12, 413);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(42, 13);
            this.Label2.TabIndex = 548;
            this.Label2.Text = "Date :";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(23, 377);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(117, 16);
            this.Label1.TabIndex = 547;
            this.Label1.Text = "II. Acouchement";
            // 
            // Consultation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.Label81);
            this.Controls.Add(this.Label82);
            this.Controls.Add(this.Label83);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel20);
            this.Controls.Add(this.panel16);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel19);
            this.Controls.Add(this.panel18);
            this.Controls.Add(this.panel17);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.MaskedTextBox46);
            this.Controls.Add(this.CheckBox28);
            this.Controls.Add(this.Label80);
            this.Controls.Add(this.Label79);
            this.Controls.Add(this.Label78);
            this.Controls.Add(this.MaskedTextBox45);
            this.Controls.Add(this.MaskedTextBox44);
            this.Controls.Add(this.MaskedTextBox43);
            this.Controls.Add(this.MaskedTextBox42);
            this.Controls.Add(this.MaskedTextBox41);
            this.Controls.Add(this.MaskedTextBox40);
            this.Controls.Add(this.MaskedTextBox39);
            this.Controls.Add(this.MaskedTextBox38);
            this.Controls.Add(this.MaskedTextBox37);
            this.Controls.Add(this.MaskedTextBox36);
            this.Controls.Add(this.MaskedTextBox35);
            this.Controls.Add(this.MaskedTextBox34);
            this.Controls.Add(this.MaskedTextBox33);
            this.Controls.Add(this.MaskedTextBox32);
            this.Controls.Add(this.MaskedTextBox31);
            this.Controls.Add(this.MaskedTextBox30);
            this.Controls.Add(this.MaskedTextBox29);
            this.Controls.Add(this.Label77);
            this.Controls.Add(this.Label76);
            this.Controls.Add(this.Label75);
            this.Controls.Add(this.Label74);
            this.Controls.Add(this.Label73);
            this.Controls.Add(this.Label72);
            this.Controls.Add(this.Label71);
            this.Controls.Add(this.Label70);
            this.Controls.Add(this.Label69);
            this.Controls.Add(this.Label68);
            this.Controls.Add(this.Label67);
            this.Controls.Add(this.Label66);
            this.Controls.Add(this.Label65);
            this.Controls.Add(this.Label64);
            this.Controls.Add(this.Label63);
            this.Controls.Add(this.Label62);
            this.Controls.Add(this.Label61);
            this.Controls.Add(this.Label60);
            this.Controls.Add(this.Label59);
            this.Controls.Add(this.Label58);
            this.Controls.Add(this.Label57);
            this.Controls.Add(this.CheckBox27);
            this.Controls.Add(this.CheckBox26);
            this.Controls.Add(this.CheckBox25);
            this.Controls.Add(this.CheckBox24);
            this.Controls.Add(this.CheckBox23);
            this.Controls.Add(this.CheckBox22);
            this.Controls.Add(this.CheckBox21);
            this.Controls.Add(this.CheckBox20);
            this.Controls.Add(this.CheckBox19);
            this.Controls.Add(this.CheckBox18);
            this.Controls.Add(this.CheckBox17);
            this.Controls.Add(this.CheckBox16);
            this.Controls.Add(this.CheckBox15);
            this.Controls.Add(this.CheckBox14);
            this.Controls.Add(this.CheckBox13);
            this.Controls.Add(this.CheckBox12);
            this.Controls.Add(this.CheckBox11);
            this.Controls.Add(this.CheckBox10);
            this.Controls.Add(this.CheckBox9);
            this.Controls.Add(this.CheckBox8);
            this.Controls.Add(this.CheckBox7);
            this.Controls.Add(this.Label56);
            this.Controls.Add(this.Label55);
            this.Controls.Add(this.Label54);
            this.Controls.Add(this.Label53);
            this.Controls.Add(this.Label52);
            this.Controls.Add(this.Label51);
            this.Controls.Add(this.Label50);
            this.Controls.Add(this.Label49);
            this.Controls.Add(this.Label48);
            this.Controls.Add(this.Label47);
            this.Controls.Add(this.Label46);
            this.Controls.Add(this.Label45);
            this.Controls.Add(this.Label43);
            this.Controls.Add(this.Label42);
            this.Controls.Add(this.Label28);
            this.Controls.Add(this.DataGridView7);
            this.Controls.Add(this.DataGridView6);
            this.Controls.Add(this.DataGridView5);
            this.Controls.Add(this.DataGridView4);
            this.Controls.Add(this.DataGridView3);
            this.Controls.Add(this.MaskedTextBox28);
            this.Controls.Add(this.MaskedTextBox27);
            this.Controls.Add(this.MaskedTextBox26);
            this.Controls.Add(this.MaskedTextBox25);
            this.Controls.Add(this.MaskedTextBox24);
            this.Controls.Add(this.MaskedTextBox23);
            this.Controls.Add(this.MaskedTextBox22);
            this.Controls.Add(this.MaskedTextBox21);
            this.Controls.Add(this.MaskedTextBox20);
            this.Controls.Add(this.MaskedTextBox19);
            this.Controls.Add(this.MaskedTextBox18);
            this.Controls.Add(this.MaskedTextBox17);
            this.Controls.Add(this.MaskedTextBox16);
            this.Controls.Add(this.Label44);
            this.Controls.Add(this.Label41);
            this.Controls.Add(this.Label40);
            this.Controls.Add(this.Label39);
            this.Controls.Add(this.Label38);
            this.Controls.Add(this.Label37);
            this.Controls.Add(this.Label36);
            this.Controls.Add(this.Label35);
            this.Controls.Add(this.Label34);
            this.Controls.Add(this.Label33);
            this.Controls.Add(this.Label32);
            this.Controls.Add(this.Label31);
            this.Controls.Add(this.Label30);
            this.Controls.Add(this.Label29);
            this.Controls.Add(this.Label27);
            this.Controls.Add(this.Label26);
            this.Controls.Add(this.DataGridView2);
            this.Controls.Add(this.MaskedTextBox15);
            this.Controls.Add(this.MaskedTextBox14);
            this.Controls.Add(this.MaskedTextBox13);
            this.Controls.Add(this.MaskedTextBox12);
            this.Controls.Add(this.MaskedTextBox11);
            this.Controls.Add(this.Label25);
            this.Controls.Add(this.Label24);
            this.Controls.Add(this.Label23);
            this.Controls.Add(this.Label22);
            this.Controls.Add(this.Label21);
            this.Controls.Add(this.Label20);
            this.Controls.Add(this.Label19);
            this.Controls.Add(this.MaskedTextBox10);
            this.Controls.Add(this.MaskedTextBox9);
            this.Controls.Add(this.MaskedTextBox8);
            this.Controls.Add(this.CheckBox6);
            this.Controls.Add(this.CheckBox5);
            this.Controls.Add(this.CheckBox4);
            this.Controls.Add(this.CheckBox3);
            this.Controls.Add(this.Label18);
            this.Controls.Add(this.Label17);
            this.Controls.Add(this.Label16);
            this.Controls.Add(this.Label15);
            this.Controls.Add(this.Label14);
            this.Controls.Add(this.Label13);
            this.Controls.Add(this.Label12);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.MaskedTextBox7);
            this.Controls.Add(this.MaskedTextBox6);
            this.Controls.Add(this.MaskedTextBox5);
            this.Controls.Add(this.CheckBox2);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.CheckBox1);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.MaskedTextBox4);
            this.Controls.Add(this.MaskedTextBox3);
            this.Controls.Add(this.MaskedTextBox2);
            this.Controls.Add(this.MaskedTextBox1);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Name = "Consultation";
            this.Text = "Consultation";
            this.panel18.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label81;
        private System.Windows.Forms.Label Label82;
        private System.Windows.Forms.Label Label83;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel1;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox46;
        internal System.Windows.Forms.CheckBox CheckBox28;
        internal System.Windows.Forms.Label Label80;
        internal System.Windows.Forms.Label Label79;
        internal System.Windows.Forms.Label Label78;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox45;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox44;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox43;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox42;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox41;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox40;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox39;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox38;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox37;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox36;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox35;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox34;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox33;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox32;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox31;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox30;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox29;
        internal System.Windows.Forms.Label Label77;
        internal System.Windows.Forms.Label Label76;
        internal System.Windows.Forms.Label Label75;
        internal System.Windows.Forms.Label Label74;
        internal System.Windows.Forms.Label Label73;
        internal System.Windows.Forms.Label Label72;
        internal System.Windows.Forms.Label Label71;
        internal System.Windows.Forms.Label Label70;
        internal System.Windows.Forms.Label Label69;
        internal System.Windows.Forms.Label Label68;
        internal System.Windows.Forms.Label Label67;
        internal System.Windows.Forms.Label Label66;
        internal System.Windows.Forms.Label Label65;
        internal System.Windows.Forms.Label Label64;
        internal System.Windows.Forms.Label Label63;
        internal System.Windows.Forms.Label Label62;
        internal System.Windows.Forms.Label Label61;
        internal System.Windows.Forms.Label Label60;
        internal System.Windows.Forms.Label Label59;
        internal System.Windows.Forms.Label Label58;
        internal System.Windows.Forms.Label Label57;
        internal System.Windows.Forms.CheckBox CheckBox27;
        internal System.Windows.Forms.CheckBox CheckBox26;
        internal System.Windows.Forms.CheckBox CheckBox25;
        internal System.Windows.Forms.CheckBox CheckBox24;
        internal System.Windows.Forms.CheckBox CheckBox23;
        internal System.Windows.Forms.CheckBox CheckBox22;
        internal System.Windows.Forms.CheckBox CheckBox21;
        internal System.Windows.Forms.CheckBox CheckBox20;
        internal System.Windows.Forms.CheckBox CheckBox19;
        internal System.Windows.Forms.CheckBox CheckBox18;
        internal System.Windows.Forms.CheckBox CheckBox17;
        internal System.Windows.Forms.CheckBox CheckBox16;
        internal System.Windows.Forms.CheckBox CheckBox15;
        internal System.Windows.Forms.CheckBox CheckBox14;
        internal System.Windows.Forms.CheckBox CheckBox13;
        internal System.Windows.Forms.CheckBox CheckBox12;
        internal System.Windows.Forms.CheckBox CheckBox11;
        internal System.Windows.Forms.CheckBox CheckBox10;
        internal System.Windows.Forms.CheckBox CheckBox9;
        internal System.Windows.Forms.CheckBox CheckBox8;
        internal System.Windows.Forms.CheckBox CheckBox7;
        internal System.Windows.Forms.Label Label56;
        internal System.Windows.Forms.Label Label55;
        internal System.Windows.Forms.Label Label54;
        internal System.Windows.Forms.Label Label53;
        internal System.Windows.Forms.Label Label52;
        internal System.Windows.Forms.Label Label51;
        internal System.Windows.Forms.Label Label50;
        internal System.Windows.Forms.Label Label49;
        internal System.Windows.Forms.Label Label48;
        internal System.Windows.Forms.Label Label47;
        internal System.Windows.Forms.Label Label46;
        internal System.Windows.Forms.Label Label45;
        internal System.Windows.Forms.Label Label43;
        internal System.Windows.Forms.Label Label42;
        internal System.Windows.Forms.Label Label28;
        internal System.Windows.Forms.DataGridView DataGridView7;
        internal System.Windows.Forms.DataGridView DataGridView6;
        internal System.Windows.Forms.DataGridView DataGridView5;
        internal System.Windows.Forms.DataGridView DataGridView4;
        internal System.Windows.Forms.DataGridView DataGridView3;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox28;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox27;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox26;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox25;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox24;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox23;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox22;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox21;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox20;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox19;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox18;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox17;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox16;
        internal System.Windows.Forms.Label Label44;
        internal System.Windows.Forms.Label Label41;
        internal System.Windows.Forms.Label Label40;
        internal System.Windows.Forms.Label Label39;
        internal System.Windows.Forms.Label Label38;
        internal System.Windows.Forms.Label Label37;
        internal System.Windows.Forms.Label Label36;
        internal System.Windows.Forms.Label Label35;
        internal System.Windows.Forms.Label Label34;
        internal System.Windows.Forms.Label Label33;
        internal System.Windows.Forms.Label Label32;
        internal System.Windows.Forms.Label Label31;
        internal System.Windows.Forms.Label Label30;
        internal System.Windows.Forms.Label Label29;
        internal System.Windows.Forms.Label Label27;
        internal System.Windows.Forms.Label Label26;
        internal System.Windows.Forms.DataGridView DataGridView2;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox15;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox14;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox13;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox12;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox11;
        internal System.Windows.Forms.Label Label25;
        internal System.Windows.Forms.Label Label24;
        internal System.Windows.Forms.Label Label23;
        internal System.Windows.Forms.Label Label22;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.Label Label20;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox10;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox9;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox8;
        internal System.Windows.Forms.CheckBox CheckBox6;
        internal System.Windows.Forms.CheckBox CheckBox5;
        internal System.Windows.Forms.CheckBox CheckBox4;
        internal System.Windows.Forms.CheckBox CheckBox3;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox7;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox6;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox5;
        internal System.Windows.Forms.CheckBox CheckBox2;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.CheckBox CheckBox1;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox4;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox3;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox2;
        internal System.Windows.Forms.MaskedTextBox MaskedTextBox1;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label1;
    }
}