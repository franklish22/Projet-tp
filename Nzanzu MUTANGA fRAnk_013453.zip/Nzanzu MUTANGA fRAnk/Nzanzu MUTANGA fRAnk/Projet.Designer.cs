﻿namespace Nzanzu_MUTANGA_fRAnk
{
    partial class Projet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnexcel = new System.Windows.Forms.Button();
            this.btnenregistrer = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtpt = new System.Windows.Forms.TextBox();
            this.lblpt = new System.Windows.Forms.Label();
            this.btncalcul = new System.Windows.Forms.Button();
            this.calc = new System.Windows.Forms.Button();
            this.mskpu = new System.Windows.Forms.MaskedTextBox();
            this.lblprixunit = new System.Windows.Forms.Label();
            this.mskqut = new System.Windows.Forms.MaskedTextBox();
            this.lblquantite = new System.Windows.Forms.Label();
            this.cmboxprod = new System.Windows.Forms.ComboBox();
            this.lblprod = new System.Windows.Forms.Label();
            this.txtboxnom = new System.Windows.Forms.TextBox();
            this.lblnom = new System.Windows.Forms.Label();
            this.lblstatut = new System.Windows.Forms.Label();
            this.lblwelcome = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnexcel
            // 
            this.btnexcel.Location = new System.Drawing.Point(658, 53);
            this.btnexcel.Name = "btnexcel";
            this.btnexcel.Size = new System.Drawing.Size(172, 29);
            this.btnexcel.TabIndex = 51;
            this.btnexcel.Text = "Exportation a excel";
            this.btnexcel.UseVisualStyleBackColor = true;
            this.btnexcel.Click += new System.EventHandler(this.btnexcel_Click);
            // 
            // btnenregistrer
            // 
            this.btnenregistrer.Location = new System.Drawing.Point(69, 454);
            this.btnenregistrer.Name = "btnenregistrer";
            this.btnenregistrer.Size = new System.Drawing.Size(202, 36);
            this.btnenregistrer.TabIndex = 50;
            this.btnenregistrer.Text = "ENREGISTRER";
            this.btnenregistrer.UseVisualStyleBackColor = true;
            this.btnenregistrer.Click += new System.EventHandler(this.btnenregistrer_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(293, 99);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(537, 339);
            this.dataGridView1.TabIndex = 49;
            // 
            // txtpt
            // 
            this.txtpt.Location = new System.Drawing.Point(69, 409);
            this.txtpt.Multiline = true;
            this.txtpt.Name = "txtpt";
            this.txtpt.Size = new System.Drawing.Size(203, 29);
            this.txtpt.TabIndex = 48;
            // 
            // lblpt
            // 
            this.lblpt.AutoSize = true;
            this.lblpt.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lblpt.Location = new System.Drawing.Point(65, 384);
            this.lblpt.Name = "lblpt";
            this.lblpt.Size = new System.Drawing.Size(103, 26);
            this.lblpt.TabIndex = 47;
            this.lblpt.Text = "Prix Total";
            // 
            // btncalcul
            // 
            this.btncalcul.Location = new System.Drawing.Point(70, 345);
            this.btncalcul.Name = "btncalcul";
            this.btncalcul.Size = new System.Drawing.Size(202, 36);
            this.btncalcul.TabIndex = 46;
            this.btncalcul.Text = "CALCUL PRIX TOTAL";
            this.btncalcul.UseVisualStyleBackColor = true;
            this.btncalcul.Click += new System.EventHandler(this.btncalcul_Click);
            // 
            // calc
            // 
            this.calc.Location = new System.Drawing.Point(658, 6);
            this.calc.Name = "calc";
            this.calc.Size = new System.Drawing.Size(172, 29);
            this.calc.TabIndex = 45;
            this.calc.Text = "aller a calculatrice";
            this.calc.UseVisualStyleBackColor = true;
            this.calc.Click += new System.EventHandler(this.calc_Click);
            // 
            // mskpu
            // 
            this.mskpu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.mskpu.Location = new System.Drawing.Point(69, 313);
            this.mskpu.Mask = "00000";
            this.mskpu.Name = "mskpu";
            this.mskpu.Size = new System.Drawing.Size(203, 26);
            this.mskpu.TabIndex = 44;
            this.mskpu.ValidatingType = typeof(int);
            // 
            // lblprixunit
            // 
            this.lblprixunit.AutoSize = true;
            this.lblprixunit.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lblprixunit.Location = new System.Drawing.Point(64, 284);
            this.lblprixunit.Name = "lblprixunit";
            this.lblprixunit.Size = new System.Drawing.Size(127, 26);
            this.lblprixunit.TabIndex = 43;
            this.lblprixunit.Text = "Prix unitaire";
            // 
            // mskqut
            // 
            this.mskqut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.mskqut.Location = new System.Drawing.Point(69, 243);
            this.mskqut.Mask = "00000";
            this.mskqut.Name = "mskqut";
            this.mskqut.Size = new System.Drawing.Size(203, 26);
            this.mskqut.TabIndex = 42;
            this.mskqut.ValidatingType = typeof(int);
            // 
            // lblquantite
            // 
            this.lblquantite.AutoSize = true;
            this.lblquantite.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lblquantite.Location = new System.Drawing.Point(64, 214);
            this.lblquantite.Name = "lblquantite";
            this.lblquantite.Size = new System.Drawing.Size(94, 26);
            this.lblquantite.TabIndex = 41;
            this.lblquantite.Text = "Quantite";
            // 
            // cmboxprod
            // 
            this.cmboxprod.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.cmboxprod.FormattingEnabled = true;
            this.cmboxprod.Items.AddRange(new object[] {
            "Biscuit",
            "Orange",
            "Pomme",
            "Citron",
            "Carotte",
            "Bombon"});
            this.cmboxprod.Location = new System.Drawing.Point(69, 170);
            this.cmboxprod.Name = "cmboxprod";
            this.cmboxprod.Size = new System.Drawing.Size(203, 28);
            this.cmboxprod.TabIndex = 40;
            // 
            // lblprod
            // 
            this.lblprod.AutoSize = true;
            this.lblprod.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lblprod.Location = new System.Drawing.Point(64, 141);
            this.lblprod.Name = "lblprod";
            this.lblprod.Size = new System.Drawing.Size(81, 26);
            this.lblprod.TabIndex = 39;
            this.lblprod.Text = "Produit";
            // 
            // txtboxnom
            // 
            this.txtboxnom.Location = new System.Drawing.Point(69, 99);
            this.txtboxnom.Multiline = true;
            this.txtboxnom.Name = "txtboxnom";
            this.txtboxnom.Size = new System.Drawing.Size(203, 29);
            this.txtboxnom.TabIndex = 38;
            this.txtboxnom.TextChanged += new System.EventHandler(this.txtboxnom_TextChanged);
            // 
            // lblnom
            // 
            this.lblnom.AutoSize = true;
            this.lblnom.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.25F);
            this.lblnom.Location = new System.Drawing.Point(64, 70);
            this.lblnom.Name = "lblnom";
            this.lblnom.Size = new System.Drawing.Size(59, 26);
            this.lblnom.TabIndex = 37;
            this.lblnom.Text = "Nom";
            // 
            // lblstatut
            // 
            this.lblstatut.AutoSize = true;
            this.lblstatut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.lblstatut.Location = new System.Drawing.Point(89, 15);
            this.lblstatut.Name = "lblstatut";
            this.lblstatut.Size = new System.Drawing.Size(21, 20);
            this.lblstatut.TabIndex = 36;
            this.lblstatut.Text = "...";
            this.lblstatut.Click += new System.EventHandler(this.lblstatut_Click);
            // 
            // lblwelcome
            // 
            this.lblwelcome.AutoSize = true;
            this.lblwelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblwelcome.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblwelcome.Location = new System.Drawing.Point(330, 6);
            this.lblwelcome.Name = "lblwelcome";
            this.lblwelcome.Size = new System.Drawing.Size(189, 37);
            this.lblwelcome.TabIndex = 35;
            this.lblwelcome.Text = "WELCOME";
            // 
            // Projet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(851, 506);
            this.Controls.Add(this.btnexcel);
            this.Controls.Add(this.btnenregistrer);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtpt);
            this.Controls.Add(this.lblpt);
            this.Controls.Add(this.btncalcul);
            this.Controls.Add(this.calc);
            this.Controls.Add(this.mskpu);
            this.Controls.Add(this.lblprixunit);
            this.Controls.Add(this.mskqut);
            this.Controls.Add(this.lblquantite);
            this.Controls.Add(this.cmboxprod);
            this.Controls.Add(this.lblprod);
            this.Controls.Add(this.lblnom);
            this.Controls.Add(this.lblstatut);
            this.Controls.Add(this.lblwelcome);
            this.Controls.Add(this.txtboxnom);
            this.Name = "Projet";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnexcel;
        private System.Windows.Forms.Button btnenregistrer;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtpt;
        private System.Windows.Forms.Label lblpt;
        private System.Windows.Forms.Button btncalcul;
        private System.Windows.Forms.Button calc;
        private System.Windows.Forms.MaskedTextBox mskpu;
        private System.Windows.Forms.Label lblprixunit;
        private System.Windows.Forms.MaskedTextBox mskqut;
        private System.Windows.Forms.Label lblquantite;
        private System.Windows.Forms.ComboBox cmboxprod;
        private System.Windows.Forms.Label lblprod;
        private System.Windows.Forms.TextBox txtboxnom;
        private System.Windows.Forms.Label lblnom;
        private System.Windows.Forms.Label lblstatut;
        private System.Windows.Forms.Label lblwelcome;
    }
}