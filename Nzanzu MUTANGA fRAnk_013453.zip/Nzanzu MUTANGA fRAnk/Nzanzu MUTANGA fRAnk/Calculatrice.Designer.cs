﻿namespace Nzanzu_MUTANGA_fRAnk
{
    partial class Calculatrice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button BtnSoust;
            this.label1 = new System.Windows.Forms.Label();
            this.BtnClean = new System.Windows.Forms.Button();
            this.BtnEg = new System.Windows.Forms.Button();
            this.BtnDiv = new System.Windows.Forms.Button();
            this.BtnMult = new System.Windows.Forms.Button();
            this.BtnAdd = new System.Windows.Forms.Button();
            this.BtnVirg = new System.Windows.Forms.Button();
            this.Btn0 = new System.Windows.Forms.Button();
            this.Btn9 = new System.Windows.Forms.Button();
            this.Btn8 = new System.Windows.Forms.Button();
            this.Btn7 = new System.Windows.Forms.Button();
            this.Btn6 = new System.Windows.Forms.Button();
            this.Btn5 = new System.Windows.Forms.Button();
            this.Btn4 = new System.Windows.Forms.Button();
            this.Btn3 = new System.Windows.Forms.Button();
            this.Btn2 = new System.Windows.Forms.Button();
            this.Btn1 = new System.Windows.Forms.Button();
            this.Txtecrates = new System.Windows.Forms.Panel();
            this.TxtAffiche = new System.Windows.Forms.TextBox();
            BtnSoust = new System.Windows.Forms.Button();
            this.Txtecrates.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(24, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(192, 23);
            this.label1.TabIndex = 61;
            this.label1.Text = " CALCULATOR Frank";
            // 
            // BtnClean
            // 
            this.BtnClean.BackColor = System.Drawing.Color.Red;
            this.BtnClean.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnClean.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnClean.ForeColor = System.Drawing.Color.White;
            this.BtnClean.Location = new System.Drawing.Point(15, 133);
            this.BtnClean.Margin = new System.Windows.Forms.Padding(2);
            this.BtnClean.Name = "BtnClean";
            this.BtnClean.Size = new System.Drawing.Size(217, 26);
            this.BtnClean.TabIndex = 78;
            this.BtnClean.Text = "C";
            this.BtnClean.UseVisualStyleBackColor = false;
            this.BtnClean.Click += new System.EventHandler(this.BtnClean_Click);
            // 
            // BtnEg
            // 
            this.BtnEg.BackColor = System.Drawing.Color.Blue;
            this.BtnEg.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnEg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnEg.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnEg.Location = new System.Drawing.Point(121, 256);
            this.BtnEg.Margin = new System.Windows.Forms.Padding(2);
            this.BtnEg.Name = "BtnEg";
            this.BtnEg.Size = new System.Drawing.Size(59, 33);
            this.BtnEg.TabIndex = 77;
            this.BtnEg.Text = "=";
            this.BtnEg.UseVisualStyleBackColor = false;
            this.BtnEg.Click += new System.EventHandler(this.BtnEg_Click);
            // 
            // BtnDiv
            // 
            this.BtnDiv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.BtnDiv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnDiv.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnDiv.ForeColor = System.Drawing.Color.White;
            this.BtnDiv.Location = new System.Drawing.Point(184, 258);
            this.BtnDiv.Margin = new System.Windows.Forms.Padding(2);
            this.BtnDiv.Name = "BtnDiv";
            this.BtnDiv.Size = new System.Drawing.Size(48, 26);
            this.BtnDiv.TabIndex = 76;
            this.BtnDiv.Text = "/";
            this.BtnDiv.UseVisualStyleBackColor = false;
            this.BtnDiv.Click += new System.EventHandler(this.BtnDiv_Click);
            // 
            // BtnMult
            // 
            this.BtnMult.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.BtnMult.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnMult.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnMult.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnMult.Location = new System.Drawing.Point(184, 225);
            this.BtnMult.Margin = new System.Windows.Forms.Padding(2);
            this.BtnMult.Name = "BtnMult";
            this.BtnMult.Size = new System.Drawing.Size(48, 26);
            this.BtnMult.TabIndex = 75;
            this.BtnMult.Text = "X";
            this.BtnMult.UseVisualStyleBackColor = false;
            this.BtnMult.Click += new System.EventHandler(this.BtnMult_Click);
            // 
            // BtnSoust
            // 
            BtnSoust.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            BtnSoust.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            BtnSoust.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            BtnSoust.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            BtnSoust.Location = new System.Drawing.Point(184, 194);
            BtnSoust.Margin = new System.Windows.Forms.Padding(2);
            BtnSoust.Name = "BtnSoust";
            BtnSoust.Size = new System.Drawing.Size(48, 26);
            BtnSoust.TabIndex = 74;
            BtnSoust.Text = "-";
            BtnSoust.UseVisualStyleBackColor = false;
            BtnSoust.Click += new System.EventHandler(this.BtnSoust_Click);
            // 
            // BtnAdd
            // 
            this.BtnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.BtnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnAdd.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnAdd.Location = new System.Drawing.Point(184, 163);
            this.BtnAdd.Margin = new System.Windows.Forms.Padding(2);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(48, 26);
            this.BtnAdd.TabIndex = 73;
            this.BtnAdd.Text = "+";
            this.BtnAdd.UseVisualStyleBackColor = false;
            this.BtnAdd.Click += new System.EventHandler(this.BtnAdd_Click);
            // 
            // BtnVirg
            // 
            this.BtnVirg.BackColor = System.Drawing.Color.Gray;
            this.BtnVirg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnVirg.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnVirg.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.BtnVirg.Location = new System.Drawing.Point(68, 257);
            this.BtnVirg.Margin = new System.Windows.Forms.Padding(2);
            this.BtnVirg.Name = "BtnVirg";
            this.BtnVirg.Size = new System.Drawing.Size(48, 26);
            this.BtnVirg.TabIndex = 71;
            this.BtnVirg.Text = ",";
            this.BtnVirg.UseVisualStyleBackColor = false;
            this.BtnVirg.Click += new System.EventHandler(this.BtnVirg_Click);
            // 
            // Btn0
            // 
            this.Btn0.BackColor = System.Drawing.Color.Gray;
            this.Btn0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn0.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btn0.Location = new System.Drawing.Point(15, 257);
            this.Btn0.Margin = new System.Windows.Forms.Padding(2);
            this.Btn0.Name = "Btn0";
            this.Btn0.Size = new System.Drawing.Size(48, 26);
            this.Btn0.TabIndex = 70;
            this.Btn0.Text = "0";
            this.Btn0.UseVisualStyleBackColor = false;
            this.Btn0.Click += new System.EventHandler(this.Btn0_Click);
            // 
            // Btn9
            // 
            this.Btn9.BackColor = System.Drawing.Color.Gray;
            this.Btn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn9.ForeColor = System.Drawing.Color.White;
            this.Btn9.Location = new System.Drawing.Point(121, 226);
            this.Btn9.Margin = new System.Windows.Forms.Padding(2);
            this.Btn9.Name = "Btn9";
            this.Btn9.Size = new System.Drawing.Size(48, 26);
            this.Btn9.TabIndex = 69;
            this.Btn9.Text = "9";
            this.Btn9.UseVisualStyleBackColor = false;
            this.Btn9.Click += new System.EventHandler(this.Btn9_Click);
            // 
            // Btn8
            // 
            this.Btn8.BackColor = System.Drawing.Color.Gray;
            this.Btn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btn8.Location = new System.Drawing.Point(68, 226);
            this.Btn8.Margin = new System.Windows.Forms.Padding(2);
            this.Btn8.Name = "Btn8";
            this.Btn8.Size = new System.Drawing.Size(48, 26);
            this.Btn8.TabIndex = 68;
            this.Btn8.Text = "8";
            this.Btn8.UseVisualStyleBackColor = false;
            this.Btn8.Click += new System.EventHandler(this.Btn8_Click);
            // 
            // Btn7
            // 
            this.Btn7.BackColor = System.Drawing.Color.Gray;
            this.Btn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btn7.Location = new System.Drawing.Point(15, 226);
            this.Btn7.Margin = new System.Windows.Forms.Padding(2);
            this.Btn7.Name = "Btn7";
            this.Btn7.Size = new System.Drawing.Size(48, 26);
            this.Btn7.TabIndex = 67;
            this.Btn7.Text = "7";
            this.Btn7.UseVisualStyleBackColor = false;
            this.Btn7.Click += new System.EventHandler(this.Btn7_Click);
            // 
            // Btn6
            // 
            this.Btn6.BackColor = System.Drawing.Color.Gray;
            this.Btn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btn6.Location = new System.Drawing.Point(121, 195);
            this.Btn6.Margin = new System.Windows.Forms.Padding(2);
            this.Btn6.Name = "Btn6";
            this.Btn6.Size = new System.Drawing.Size(48, 26);
            this.Btn6.TabIndex = 66;
            this.Btn6.Text = "6";
            this.Btn6.UseVisualStyleBackColor = false;
            this.Btn6.Click += new System.EventHandler(this.Btn6_Click);
            // 
            // Btn5
            // 
            this.Btn5.BackColor = System.Drawing.Color.Gray;
            this.Btn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btn5.Location = new System.Drawing.Point(68, 195);
            this.Btn5.Margin = new System.Windows.Forms.Padding(2);
            this.Btn5.Name = "Btn5";
            this.Btn5.Size = new System.Drawing.Size(48, 26);
            this.Btn5.TabIndex = 65;
            this.Btn5.Text = "5";
            this.Btn5.UseVisualStyleBackColor = false;
            this.Btn5.Click += new System.EventHandler(this.Btn5_Click);
            // 
            // Btn4
            // 
            this.Btn4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Btn4.BackColor = System.Drawing.Color.Gray;
            this.Btn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btn4.Location = new System.Drawing.Point(15, 195);
            this.Btn4.Margin = new System.Windows.Forms.Padding(2);
            this.Btn4.Name = "Btn4";
            this.Btn4.Size = new System.Drawing.Size(48, 26);
            this.Btn4.TabIndex = 64;
            this.Btn4.Text = "4";
            this.Btn4.UseVisualStyleBackColor = false;
            this.Btn4.Click += new System.EventHandler(this.Btn4_Click);
            // 
            // Btn3
            // 
            this.Btn3.BackColor = System.Drawing.Color.Gray;
            this.Btn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btn3.Location = new System.Drawing.Point(121, 164);
            this.Btn3.Margin = new System.Windows.Forms.Padding(2);
            this.Btn3.Name = "Btn3";
            this.Btn3.Size = new System.Drawing.Size(48, 26);
            this.Btn3.TabIndex = 63;
            this.Btn3.Text = "3";
            this.Btn3.UseVisualStyleBackColor = false;
            this.Btn3.Click += new System.EventHandler(this.Btn3_Click);
            // 
            // Btn2
            // 
            this.Btn2.BackColor = System.Drawing.Color.Gray;
            this.Btn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btn2.Location = new System.Drawing.Point(68, 164);
            this.Btn2.Margin = new System.Windows.Forms.Padding(2);
            this.Btn2.Name = "Btn2";
            this.Btn2.Size = new System.Drawing.Size(48, 26);
            this.Btn2.TabIndex = 62;
            this.Btn2.Text = "2";
            this.Btn2.UseVisualStyleBackColor = false;
            this.Btn2.Click += new System.EventHandler(this.Btn2_Click);
            // 
            // Btn1
            // 
            this.Btn1.BackColor = System.Drawing.Color.Gray;
            this.Btn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Btn1.Location = new System.Drawing.Point(15, 164);
            this.Btn1.Margin = new System.Windows.Forms.Padding(2);
            this.Btn1.Name = "Btn1";
            this.Btn1.Size = new System.Drawing.Size(48, 26);
            this.Btn1.TabIndex = 60;
            this.Btn1.Text = "1";
            this.Btn1.UseVisualStyleBackColor = false;
            this.Btn1.Click += new System.EventHandler(this.Btn1_Click);
            // 
            // Txtecrates
            // 
            this.Txtecrates.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.Txtecrates.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Txtecrates.Controls.Add(this.TxtAffiche);
            this.Txtecrates.Location = new System.Drawing.Point(8, 52);
            this.Txtecrates.Margin = new System.Windows.Forms.Padding(2);
            this.Txtecrates.Name = "Txtecrates";
            this.Txtecrates.Size = new System.Drawing.Size(234, 58);
            this.Txtecrates.TabIndex = 59;
            // 
            // TxtAffiche
            // 
            this.TxtAffiche.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.TxtAffiche.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TxtAffiche.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtAffiche.ForeColor = System.Drawing.Color.Purple;
            this.TxtAffiche.Location = new System.Drawing.Point(5, 20);
            this.TxtAffiche.Margin = new System.Windows.Forms.Padding(2);
            this.TxtAffiche.Name = "TxtAffiche";
            this.TxtAffiche.Size = new System.Drawing.Size(219, 21);
            this.TxtAffiche.TabIndex = 0;
            this.TxtAffiche.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Calculatrice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(265, 309);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnClean);
            this.Controls.Add(this.BtnEg);
            this.Controls.Add(this.BtnDiv);
            this.Controls.Add(this.BtnMult);
            this.Controls.Add(BtnSoust);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(this.BtnVirg);
            this.Controls.Add(this.Btn0);
            this.Controls.Add(this.Btn9);
            this.Controls.Add(this.Btn8);
            this.Controls.Add(this.Btn7);
            this.Controls.Add(this.Btn6);
            this.Controls.Add(this.Btn5);
            this.Controls.Add(this.Btn4);
            this.Controls.Add(this.Btn3);
            this.Controls.Add(this.Btn2);
            this.Controls.Add(this.Btn1);
            this.Controls.Add(this.Txtecrates);
            this.Name = "Calculatrice";
            this.Text = "Calculatrice";
            this.Txtecrates.ResumeLayout(false);
            this.Txtecrates.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnClean;
        private System.Windows.Forms.Button BtnEg;
        private System.Windows.Forms.Button BtnDiv;
        private System.Windows.Forms.Button BtnMult;
        private System.Windows.Forms.Button BtnAdd;
        private System.Windows.Forms.Button BtnVirg;
        private System.Windows.Forms.Button Btn0;
        private System.Windows.Forms.Button Btn9;
        private System.Windows.Forms.Button Btn8;
        private System.Windows.Forms.Button Btn7;
        private System.Windows.Forms.Button Btn6;
        private System.Windows.Forms.Button Btn5;
        private System.Windows.Forms.Button Btn4;
        private System.Windows.Forms.Button Btn3;
        private System.Windows.Forms.Button Btn2;
        private System.Windows.Forms.Button Btn1;
        private System.Windows.Forms.Panel Txtecrates;
        private System.Windows.Forms.TextBox TxtAffiche;
    }
}