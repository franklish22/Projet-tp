﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nzanzu_MUTANGA_fRAnk
{
    public partial class Consultation : Form
    {
        public Consultation()
        {
            InitializeComponent();
        }

        private void DataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void CheckBox28_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Label80_Click(object sender, EventArgs e)
        {

        }

        private void Label79_Click(object sender, EventArgs e)
        {

        }

        private void Label78_Click(object sender, EventArgs e)
        {

        }

        private void MaskedTextBox45_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox44_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox43_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox42_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox41_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox40_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox39_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox38_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox37_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox36_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox35_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox34_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox33_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox32_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox31_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox30_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void MaskedTextBox29_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void Label77_Click(object sender, EventArgs e)
        {

        }

        private void Label76_Click(object sender, EventArgs e)
        {

        }

        private void Label75_Click(object sender, EventArgs e)
        {

        }

        private void Label74_Click(object sender, EventArgs e)
        {

        }

        private void Label73_Click(object sender, EventArgs e)
        {

        }

        private void Label72_Click(object sender, EventArgs e)
        {

        }

        private void Label71_Click(object sender, EventArgs e)
        {

        }

        private void Label70_Click(object sender, EventArgs e)
        {

        }

        private void Label69_Click(object sender, EventArgs e)
        {

        }

        private void Label68_Click(object sender, EventArgs e)
        {

        }

        private void Label67_Click(object sender, EventArgs e)
        {

        }

        private void Label66_Click(object sender, EventArgs e)
        {

        }

        private void Label65_Click(object sender, EventArgs e)
        {

        }

        private void Label64_Click(object sender, EventArgs e)
        {

        }

        private void Label63_Click(object sender, EventArgs e)
        {

        }

        private void Label62_Click(object sender, EventArgs e)
        {

        }

        private void Label61_Click(object sender, EventArgs e)
        {

        }

        private void Label60_Click(object sender, EventArgs e)
        {

        }

        private void Label59_Click(object sender, EventArgs e)
        {

        }

        private void Label58_Click(object sender, EventArgs e)
        {

        }

        private void Label57_Click(object sender, EventArgs e)
        {

        }

        private void CheckBox27_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox26_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox25_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox24_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox23_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox22_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox21_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox20_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox19_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox18_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox17_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox16_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox15_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox14_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox13_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox12_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox11_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox10_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox9_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox8_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void CheckBox7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Label56_Click(object sender, EventArgs e)
        {

        }

        private void Label55_Click(object sender, EventArgs e)
        {

        }

        private void Label54_Click(object sender, EventArgs e)
        {

        }

        private void Label53_Click(object sender, EventArgs e)
        {

        }

        private void Label52_Click(object sender, EventArgs e)
        {

        }

        private void Label51_Click(object sender, EventArgs e)
        {

        }

        private void Label50_Click(object sender, EventArgs e)
        {

        }

        private void Label49_Click(object sender, EventArgs e)
        {

        }

        private void Label48_Click(object sender, EventArgs e)
        {

        }

        private void Label47_Click(object sender, EventArgs e)
        {

        }

        private void Label46_Click(object sender, EventArgs e)
        {

        }

        private void Label45_Click(object sender, EventArgs e)
        {

        }

        private void Label43_Click(object sender, EventArgs e)
        {

        }

        private void Label42_Click(object sender, EventArgs e)
        {

        }

        private void Label28_Click(object sender, EventArgs e)
        {

        }

        private void DataGridView7_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DataGridView6_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DataGridView5_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void MaskedTextBox46_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void DataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
