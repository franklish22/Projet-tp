﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nzanzu_MUTANGA_fRAnk
{
    public partial class Loging : Form
    {
        public Loging()
        {
            InitializeComponent();
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }
    }
}
