﻿namespace Nzanzu_MUTANGA_fRAnk
{
    partial class Jeu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Jeu));
            this.btnQuitter = new System.Windows.Forms.Button();
            this.btnRejouer = new System.Windows.Forms.Button();
            this.grpReponse = new System.Windows.Forms.GroupBox();
            this.lblMessage = new System.Windows.Forms.Label();
            this.grpValeur = new System.Windows.Forms.GroupBox();
            this.btnValider = new System.Windows.Forms.Button();
            this.txtValeur = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.grpReponse.SuspendLayout();
            this.grpValeur.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnQuitter
            // 
            this.btnQuitter.Image = ((System.Drawing.Image)(resources.GetObject("btnQuitter.Image")));
            this.btnQuitter.Location = new System.Drawing.Point(183, 79);
            this.btnQuitter.Margin = new System.Windows.Forms.Padding(2);
            this.btnQuitter.Name = "btnQuitter";
            this.btnQuitter.Size = new System.Drawing.Size(42, 41);
            this.btnQuitter.TabIndex = 25;
            this.btnQuitter.UseVisualStyleBackColor = true;
            this.btnQuitter.Click += new System.EventHandler(this.btnQuitter_Click_1);
            // 
            // btnRejouer
            // 
            this.btnRejouer.BackColor = System.Drawing.Color.Red;
            this.btnRejouer.Image = ((System.Drawing.Image)(resources.GetObject("btnRejouer.Image")));
            this.btnRejouer.Location = new System.Drawing.Point(183, 23);
            this.btnRejouer.Margin = new System.Windows.Forms.Padding(2);
            this.btnRejouer.Name = "btnRejouer";
            this.btnRejouer.Size = new System.Drawing.Size(42, 46);
            this.btnRejouer.TabIndex = 24;
            this.btnRejouer.UseVisualStyleBackColor = false;
            this.btnRejouer.Click += new System.EventHandler(this.btnRejouer_Click);
            // 
            // grpReponse
            // 
            this.grpReponse.Controls.Add(this.lblMessage);
            this.grpReponse.Location = new System.Drawing.Point(26, 78);
            this.grpReponse.Margin = new System.Windows.Forms.Padding(2);
            this.grpReponse.Name = "grpReponse";
            this.grpReponse.Padding = new System.Windows.Forms.Padding(2);
            this.grpReponse.Size = new System.Drawing.Size(153, 42);
            this.grpReponse.TabIndex = 23;
            this.grpReponse.TabStop = false;
            // 
            // lblMessage
            // 
            this.lblMessage.AutoSize = true;
            this.lblMessage.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblMessage.Location = new System.Drawing.Point(7, 29);
            this.lblMessage.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(35, 13);
            this.lblMessage.TabIndex = 0;
            this.lblMessage.Text = "label2";
            // 
            // grpValeur
            // 
            this.grpValeur.Controls.Add(this.btnValider);
            this.grpValeur.Controls.Add(this.txtValeur);
            this.grpValeur.Location = new System.Drawing.Point(26, 23);
            this.grpValeur.Margin = new System.Windows.Forms.Padding(2);
            this.grpValeur.Name = "grpValeur";
            this.grpValeur.Padding = new System.Windows.Forms.Padding(2);
            this.grpValeur.Size = new System.Drawing.Size(153, 51);
            this.grpValeur.TabIndex = 22;
            this.grpValeur.TabStop = false;
            // 
            // btnValider
            // 
            this.btnValider.BackColor = System.Drawing.Color.Maroon;
            this.btnValider.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnValider.Location = new System.Drawing.Point(116, 13);
            this.btnValider.Margin = new System.Windows.Forms.Padding(2);
            this.btnValider.Name = "btnValider";
            this.btnValider.Size = new System.Drawing.Size(36, 28);
            this.btnValider.TabIndex = 1;
            this.btnValider.Text = "OK";
            this.btnValider.UseVisualStyleBackColor = false;
            this.btnValider.Click += new System.EventHandler(this.btnValider_Click);
            // 
            // txtValeur
            // 
            this.txtValeur.Location = new System.Drawing.Point(4, 16);
            this.txtValeur.Margin = new System.Windows.Forms.Padding(2);
            this.txtValeur.Name = "txtValeur";
            this.txtValeur.Size = new System.Drawing.Size(109, 20);
            this.txtValeur.TabIndex = 0;
            this.txtValeur.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 30);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 21;
            // 
            // Jeu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(246, 141);
            this.Controls.Add(this.btnQuitter);
            this.Controls.Add(this.btnRejouer);
            this.Controls.Add(this.grpReponse);
            this.Controls.Add(this.grpValeur);
            this.Controls.Add(this.label1);
            this.Name = "Jeu";
            this.Text = "Jeu";
            this.grpReponse.ResumeLayout(false);
            this.grpReponse.PerformLayout();
            this.grpValeur.ResumeLayout(false);
            this.grpValeur.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnQuitter;
        private System.Windows.Forms.Button btnRejouer;
        private System.Windows.Forms.GroupBox grpReponse;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.GroupBox grpValeur;
        private System.Windows.Forms.Button btnValider;
        private System.Windows.Forms.TextBox txtValeur;
        private System.Windows.Forms.Label label1;
    }
}