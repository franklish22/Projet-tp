﻿namespace Nzanzu_MUTANGA_fRAnk
{
    partial class Operation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Operation));
            this.btneteindre = new System.Windows.Forms.Button();
            this.btngomme = new System.Windows.Forms.Button();
            this.lblegal = new System.Windows.Forms.Label();
            this.txtresult = new System.Windows.Forms.TextBox();
            this.lblmulti = new System.Windows.Forms.Label();
            this.txtnbr2 = new System.Windows.Forms.TextBox();
            this.txtnbr1 = new System.Windows.Forms.TextBox();
            this.btnmultip = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btneteindre
            // 
            this.btneteindre.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.btneteindre.Image = ((System.Drawing.Image)(resources.GetObject("btneteindre.Image")));
            this.btneteindre.Location = new System.Drawing.Point(261, 121);
            this.btneteindre.Name = "btneteindre";
            this.btneteindre.Size = new System.Drawing.Size(74, 58);
            this.btneteindre.TabIndex = 26;
            this.btneteindre.UseVisualStyleBackColor = true;
            this.btneteindre.Click += new System.EventHandler(this.btneteindre_Click);
            // 
            // btngomme
            // 
            this.btngomme.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.btngomme.Image = ((System.Drawing.Image)(resources.GetObject("btngomme.Image")));
            this.btngomme.Location = new System.Drawing.Point(261, 39);
            this.btngomme.Name = "btngomme";
            this.btngomme.Size = new System.Drawing.Size(74, 61);
            this.btngomme.TabIndex = 25;
            this.btngomme.UseVisualStyleBackColor = true;
            this.btngomme.Click += new System.EventHandler(this.btngomme_Click);
            // 
            // lblegal
            // 
            this.lblegal.AutoSize = true;
            this.lblegal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.lblegal.Location = new System.Drawing.Point(6, 116);
            this.lblegal.Name = "lblegal";
            this.lblegal.Size = new System.Drawing.Size(30, 31);
            this.lblegal.TabIndex = 24;
            this.lblegal.Text = "=";
            // 
            // txtresult
            // 
            this.txtresult.Enabled = false;
            this.txtresult.Location = new System.Drawing.Point(41, 121);
            this.txtresult.Multiline = true;
            this.txtresult.Name = "txtresult";
            this.txtresult.Size = new System.Drawing.Size(120, 21);
            this.txtresult.TabIndex = 23;
            this.txtresult.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblmulti
            // 
            this.lblmulti.AutoSize = true;
            this.lblmulti.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmulti.Location = new System.Drawing.Point(9, 77);
            this.lblmulti.Name = "lblmulti";
            this.lblmulti.Size = new System.Drawing.Size(15, 18);
            this.lblmulti.TabIndex = 22;
            this.lblmulti.Text = "x";
            // 
            // txtnbr2
            // 
            this.txtnbr2.Location = new System.Drawing.Point(41, 79);
            this.txtnbr2.Multiline = true;
            this.txtnbr2.Name = "txtnbr2";
            this.txtnbr2.Size = new System.Drawing.Size(120, 21);
            this.txtnbr2.TabIndex = 21;
            this.txtnbr2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtnbr2.TextChanged += new System.EventHandler(this.txtnbr2_TextChanged);
            // 
            // txtnbr1
            // 
            this.txtnbr1.Location = new System.Drawing.Point(41, 39);
            this.txtnbr1.Multiline = true;
            this.txtnbr1.Name = "txtnbr1";
            this.txtnbr1.Size = new System.Drawing.Size(120, 22);
            this.txtnbr1.TabIndex = 20;
            this.txtnbr1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtnbr1.TextChanged += new System.EventHandler(this.txtnbr1_TextChanged);
            // 
            // btnmultip
            // 
            this.btnmultip.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.btnmultip.Location = new System.Drawing.Point(180, 121);
            this.btnmultip.Name = "btnmultip";
            this.btnmultip.Size = new System.Drawing.Size(74, 58);
            this.btnmultip.TabIndex = 19;
            this.btnmultip.Text = "x";
            this.btnmultip.UseVisualStyleBackColor = true;
            this.btnmultip.Click += new System.EventHandler(this.btnmultip_Click);
            // 
            // btnadd
            // 
            this.btnadd.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F);
            this.btnadd.Location = new System.Drawing.Point(180, 39);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(74, 61);
            this.btnadd.TabIndex = 18;
            this.btnadd.Text = "+";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // Operation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(365, 197);
            this.Controls.Add(this.btneteindre);
            this.Controls.Add(this.btngomme);
            this.Controls.Add(this.lblegal);
            this.Controls.Add(this.txtresult);
            this.Controls.Add(this.lblmulti);
            this.Controls.Add(this.txtnbr2);
            this.Controls.Add(this.txtnbr1);
            this.Controls.Add(this.btnmultip);
            this.Controls.Add(this.btnadd);
            this.Name = "Operation";
            this.Text = "Operation";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btneteindre;
        private System.Windows.Forms.Button btngomme;
        private System.Windows.Forms.Label lblegal;
        private System.Windows.Forms.TextBox txtresult;
        private System.Windows.Forms.Label lblmulti;
        private System.Windows.Forms.TextBox txtnbr2;
        private System.Windows.Forms.TextBox txtnbr1;
        private System.Windows.Forms.Button btnmultip;
        private System.Windows.Forms.Button btnadd;
    }
}